<?php defined('ABSPATH') || exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('f-theme f-' . farhoon_lang()); ?>>
<?php wp_body_open(); ?>
<a class="f-skip" href="#main"><?php echo esc_html(farhoon_t('انتقل إلى المحتوى', 'Skip to content')); ?></a>
<header class="f-site-header">
	<div class="f-hwrap">
		<a class="f-logo" href="<?php echo esc_url(farhoon_url('home')); ?>" aria-label="<?php echo esc_attr(farhoon_t('فرحون، الصفحة الرئيسية', 'Farhoon home')); ?>">
			<img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/img/logo-dark.png'); ?>" alt="<?php echo esc_attr(farhoon_t('فرحون', 'Farhoon')); ?>" width="116" height="62">
		</a>
		<?php farhoon_nav(); ?>
	</div>
</header>
