<?php
// Blog list: the Arabic blog, the English blog and every category, with more articles loading as you scroll.
defined('ABSPATH') || exit;
get_header();
$is_list = is_home() || is_post_type_archive('en_post');
$title = $is_list ? farhoon_t('المدونة', 'Blog') : single_term_title('', false);
$intro = $is_list
	? farhoon_t('مقالات في العبادات والزكاة وتربية الأطفال والقرآن، نكتبها بعناية ونراجعها على مصادرها.', 'Articles on worship, zakat, raising children and the Quran, written with care and checked against their sources.')
	: wp_strip_all_tags(term_description());
global $wp_query;
$paged = max(1, (int) get_query_var('paged'));
?>
<main id="main" class="f-main">
	<section class="f-band">
		<div class="f-wrap">
			<h1><?php echo esc_html($title); ?></h1>
			<?php if ($intro) : ?><p class="f-band-sub"><?php echo esc_html($intro); ?></p><?php endif; ?>
			<?php farhoon_breadcrumbs(); ?>
		</div>
	</section>
	<div class="f-wrap f-list">
		<?php farhoon_category_buttons(); ?>
		<?php if (have_posts()) : ?>
			<div class="f-grid" data-infinite>
				<?php $i = 0; while (have_posts()) : the_post(); farhoon_card($paged === 1 && $i++ < 3); endwhile; ?>
			</div>
			<?php if ($wp_query->max_num_pages > $paged) : ?>
				<div class="f-more"><a class="f-btn f-next" href="<?php echo esc_url(next_posts($wp_query->max_num_pages, false)); ?>"><?php echo esc_html(farhoon_t('مقالات أكثر', 'More articles')); ?></a></div>
			<?php endif; ?>
		<?php else : ?>
			<p class="f-empty"><?php echo esc_html(farhoon_t('لا توجد مقالات هنا بعد.', 'No articles here yet.')); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer();
