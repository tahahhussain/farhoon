<?php defined('ABSPATH') || exit; ?>
<footer class="f-site-footer">
	<div class="f-fwrap">
		<a href="<?php echo esc_url(farhoon_url('home')); ?>"><img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/img/logo-dark.png'); ?>" alt="<?php echo esc_attr(farhoon_t('فرحون', 'Farhoon')); ?>" width="100" height="54" loading="lazy"></a>
		<nav aria-label="<?php echo esc_attr(farhoon_t('روابط الموقع', 'Site links')); ?>">
			<a href="<?php echo esc_url(farhoon_url('home')); ?>"><?php echo esc_html(farhoon_t('الرئيسية', 'Home')); ?></a>
			<a href="<?php echo esc_url(farhoon_url('about')); ?>"><?php echo esc_html(farhoon_t('من نحن', 'About')); ?></a>
			<a href="<?php echo esc_url(farhoon_url('rafiq')); ?>"><?php echo esc_html(farhoon_t('رفيق الطاعة', 'Rafiq Al-Taa')); ?></a>
			<a href="<?php echo esc_url(farhoon_lang() === 'en' ? get_post_type_archive_link('en_post') : farhoon_url('blog')); ?>"><?php echo esc_html(farhoon_t('المدونة', 'Blog')); ?></a>
			<a href="<?php echo esc_url(farhoon_url('contact')); ?>"><?php echo esc_html(farhoon_t('تواصل معنا', 'Contact')); ?></a>
			<a href="<?php echo esc_url(farhoon_url('privacy')); ?>"><?php echo esc_html(farhoon_t('سياسة الخصوصية', 'Privacy policy')); ?></a>
		</nav>
		<p>© <?php echo esc_html(farhoon_t('٢٠٢٦ فرحون', '2026 Farhoon')); ?><br><a href="mailto:hello@farhoon.com">hello@farhoon.com</a></p>
	</div>
</footer>
<button type="button" class="f-top" aria-label="<?php echo esc_attr(farhoon_t('العودة إلى الأعلى', 'Back to top')); ?>">↑</button>
<?php wp_footer(); ?>
</body>
</html>
