<?php
/**
 * Farhoon child theme: Arabic and English blog, article template, SEO tags, speed and security settings.
 */
defined('ABSPATH') || exit;
define('FARHOON_VER', '1.0.6');
require_once __DIR__ . '/inc/contact.php';
// No editing of theme or plugin code from the dashboard: a stolen login cannot plant code that way.
if (!defined('DISALLOW_FILE_EDIT')) define('DISALLOW_FILE_EDIT', true);

/* ---------- language ---------- */

function farhoon_is_en_page($post = null) {
	$post = get_post($post);
	if (!$post || $post->post_type !== 'page') return false;
	$uri = get_page_uri($post);
	return $uri === 'en' || strpos($uri, 'en/') === 0;
}

function farhoon_lang() {
	if (is_singular('en_post') || is_post_type_archive('en_post') || is_tax('en_category')) return 'en';
	if (is_page() && farhoon_is_en_page(get_queried_object_id())) return 'en';
	return 'ar';
}

function farhoon_t($ar, $en) {
	return farhoon_lang() === 'en' ? $en : $ar;
}

// English pages and articles declare their own language to browsers and search engines.
add_filter('language_attributes', function ($out) {
	if (is_admin() || farhoon_lang() !== 'en') return $out;
	$dir = (is_singular('en_post') || is_post_type_archive('en_post') || is_tax('en_category')) ? 'ltr' : 'rtl';
	return 'lang="en" dir="' . $dir . '"';
});

/* ---------- English articles ---------- */

add_action('init', function () {
	// Categories first, so their addresses are matched before article addresses.
	register_taxonomy('en_category', 'en_post', [
		'label' => 'English categories',
		'hierarchical' => true,
		'public' => true,
		'show_in_rest' => true,
		'show_admin_column' => true,
		'rewrite' => ['slug' => 'en/blog/category', 'with_front' => false],
	]);
	register_post_type('en_post', [
		'labels' => ['name' => 'English articles', 'singular_name' => 'English article', 'add_new_item' => 'Add English article'],
		'public' => true,
		'show_in_rest' => true,
		'has_archive' => 'en/blog',
		'rewrite' => ['slug' => 'en/blog', 'with_front' => false],
		'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'author', 'comments', 'custom-fields', 'revisions'],
		'menu_icon' => 'dashicons-translation',
		'menu_position' => 6,
		'taxonomies' => ['en_category'],
	]);
	foreach (['farhoon_faq', 'farhoon_pair', 'farhoon_minutes', 'farhoon_snippet_query'] as $key) {
		register_post_meta('', $key, ['show_in_rest' => true, 'single' => true, 'type' => 'string']);
	}
});

/* ---------- theme setup and assets ---------- */

add_action('after_setup_theme', function () {
	add_theme_support('post-thumbnails');
	add_theme_support('title-tag');
	add_image_size('farhoon-card', 640, 360, true);
	add_image_size('farhoon-hero', 1200, 675, true);
}, 20);

add_action('wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory_uri();
	wp_enqueue_style('farhoon', $dir . '/assets/site.css', [], FARHOON_VER);
	if (!farhoon_is_elementor_page()) {
		wp_enqueue_script('farhoon', $dir . '/assets/site.js', [], FARHOON_VER, ['in_footer' => true, 'strategy' => 'defer']);
	}
	// Theme pages use their own header and footer, so Hello's header styles are not needed anywhere.
	wp_dequeue_style('hello-elementor-header-footer');
	// Pages built with Elementor and articles stored as HTML do not use block styles.
	if (!is_singular() || !has_blocks(get_queried_object_id())) {
		wp_dequeue_style('wp-block-library');
		wp_dequeue_style('wp-block-library-theme');
		wp_dequeue_style('global-styles');
		wp_dequeue_style('classic-theme-styles');
	}
}, 100);

// The Farhoon face is the first big picture on several pages: load it first, and at the size it is shown.
add_filter('wp_get_attachment_image_attributes', function ($attr, $attachment) {
	if (strpos(basename((string) get_attached_file($attachment->ID)), 'face-circle') === 0) {
		$attr['sizes'] = '(max-width: 767px) 190px, 300px';
		$attr['fetchpriority'] = 'high';
		$attr['loading'] = 'eager';
	}
	return $attr;
}, 10, 2);

function farhoon_is_elementor_page() {
	return is_singular('page') && get_post_meta(get_queried_object_id(), '_elementor_edit_mode', true) === 'builder';
}

add_action('wp_head', function () {
	$font = get_stylesheet_directory_uri() . '/fonts/baloo-bhaijaan-2.woff2';
	echo '<link rel="preload" href="' . esc_url($font) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	echo '<meta name="theme-color" content="#1B1446">' . "\n";
}, 1);

/* ---------- speed and security clean-up ---------- */

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('admin_print_styles', 'print_emoji_styles');
remove_filter('the_content_feed', 'wp_staticize_emoji');
remove_filter('comment_text_rss', 'wp_staticize_emoji');
remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
add_filter('the_generator', '__return_empty_string');
// Rank Math writes the description; Hello must not add a second one.
add_filter('hello_elementor_description_meta_tag', '__return_false');
add_filter('xmlrpc_enabled', '__return_false');
add_filter('wp_headers', function ($headers) {
	unset($headers['X-Pingback']);
	return $headers + [
		'X-Content-Type-Options' => 'nosniff',
		'X-Frame-Options' => 'SAMEORIGIN',
		'Referrer-Policy' => 'strict-origin-when-cross-origin',
		'Permissions-Policy' => 'camera=(), microphone=(), geolocation=(), payment=()',
	];
});
// Stop listing user names through ?author=N and the public users API.
add_action('template_redirect', function () {
	if (isset($_GET['author']) && !is_admin()) { wp_safe_redirect(home_url('/'), 301); exit; }
});
add_filter('rest_endpoints', function ($endpoints) {
	if (!is_user_logged_in()) {
		unset($endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\d]+)']);
	}
	return $endpoints;
});

/* ---------- alternate language links (hreflang) ---------- */

function farhoon_alt_urls() {
	if (is_front_page()) return ['ar' => home_url('/'), 'en' => home_url('/en/')];
	if (is_home() || is_post_type_archive('en_post')) {
		$blog = get_option('page_for_posts');
		return ['ar' => $blog ? get_permalink($blog) : home_url('/blog/'), 'en' => get_post_type_archive_link('en_post')];
	}
	if (is_page()) {
		$uri = get_page_uri(get_queried_object_id());
		if ($uri === 'en') return ['ar' => home_url('/'), 'en' => home_url('/en/')];
		if (strpos($uri, 'en/') === 0) {
			$ar = substr($uri, 3);
			return get_page_by_path($ar) ? ['ar' => home_url("/$ar/"), 'en' => home_url("/$uri/")] : [];
		}
		return get_page_by_path("en/$uri") ? ['ar' => home_url("/$uri/"), 'en' => home_url("/en/$uri/")] : [];
	}
	if (is_singular(['post', 'en_post'])) {
		$pair = (int) get_post_meta(get_queried_object_id(), 'farhoon_pair', true);
		if (!$pair || get_post_status($pair) !== 'publish') return [];
		$me = get_permalink(get_queried_object_id());
		return get_post_type() === 'post' ? ['ar' => $me, 'en' => get_permalink($pair)] : ['ar' => get_permalink($pair), 'en' => $me];
	}
	return [];
}

add_action('wp_head', function () {
	$urls = farhoon_alt_urls();
	if (!$urls) return;
	foreach ($urls as $lang => $url) echo '<link rel="alternate" hreflang="' . $lang . '" href="' . esc_url($url) . '">' . "\n";
	echo '<link rel="alternate" hreflang="x-default" href="' . esc_url($urls['ar']) . '">' . "\n";
}, 5);

/* ---------- structured data ---------- */

function farhoon_jsonld($data) {
	echo '<script type="application/ld+json">' . wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
}

add_action('wp_head', function () {
	// FAQ of an article.
	if (is_singular(['post', 'en_post'])) {
		$faq = json_decode((string) get_post_meta(get_queried_object_id(), 'farhoon_faq', true), true);
		if ($faq) {
			farhoon_jsonld(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($f) {
				return ['@type' => 'Question', 'name' => $f['q'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['a']]];
			}, $faq)]);
		}
	}
	// The app page describes the app itself.
	if (is_page()) {
		$uri = get_page_uri(get_queried_object_id());
		if ($uri === 'rafiq' || $uri === 'en/rafiq') {
			$en = $uri === 'en/rafiq';
			farhoon_jsonld([
				'@context' => 'https://schema.org',
				'@type' => 'MobileApplication',
				'name' => $en ? 'Rafiq Al-Taa' : 'رفيق الطاعة',
				'alternateName' => $en ? 'رفيق الطاعة' : 'Rafiq Al-Taa',
				'operatingSystem' => 'Android, iOS',
				'applicationCategory' => 'LifestyleApplication',
				'inLanguage' => 'ar',
				'description' => $en
					? 'A free Islamic app with no ads and no account: Mushaf, prayer times and adhan, adhkar, zakat calculator, daily deeds, Hijri calendar and more.'
					: 'تطبيق إسلامي مجاني بلا إعلانات ولا حساب: المصحف، ومواقيت الصلاة والأذان، والأذكار، وحاسبة الزكاة، وطاعاتي اليومية، والتقويم الهجري وغيرها.',
				'url' => home_url('/' . $uri . '/'),
				'image' => get_stylesheet_directory_uri() . '/img/rafiq-icon.png',
				'offers' => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD'],
				'publisher' => ['@type' => 'Organization', 'name' => 'Farhoon', 'url' => home_url('/')],
			]);
		}
	}
}, 20);

/* ---------- article content: headings, contents list, calls to action ---------- */

add_action('wp', function () {
	// Articles are stored as finished HTML, so WordPress must not add its own paragraph tags.
	if (is_singular(['post', 'en_post']) && !has_blocks(get_queried_object_id())) remove_filter('the_content', 'wpautop');
});

add_filter('the_content', function ($content) {
	if (!is_singular(['post', 'en_post']) || !in_the_loop() || !is_main_query()) return $content;
	$toc = [];
	$n = 0;
	$content = preg_replace_callback('#<h([23])([^>]*)>(.*?)</h\1>#su', function ($m) use (&$toc, &$n) {
		$n++;
		$id = 's' . $n;
		$toc[] = [(int) $m[1], $id, wp_strip_all_tags($m[3])];
		$attrs = preg_replace('/\sid="[^"]*"/', '', $m[2]);
		return '<h' . $m[1] . ' id="' . $id . '"' . $attrs . '>' . $m[3] . '</h' . $m[1] . '>';
	}, $content);
	$content = preg_replace_callback('#(?:<p>\s*)?<!--\s*CTA:(rafiq|kids)\s*-->(?:\s*</p>)?#', function ($m) {
		return farhoon_cta($m[1]);
	}, $content);
	if (count(array_filter($toc, fn($t) => $t[0] === 2)) >= 3) {
		$list = farhoon_toc_html($toc);
		$pos = strpos($content, '</p>');
		$content = $pos !== false ? substr_replace($content, '</p>' . $list, $pos, 4) : $list . $content;
	}
	return $content;
}, 20);

function farhoon_toc_html($toc) {
	$html = '<details class="f-toc" open><summary>' . esc_html(farhoon_t('محتويات المقالة', 'In this article')) . '</summary><ol>';
	$open = false;
	foreach ($toc as [$level, $id, $text]) {
		if ($level === 2) {
			if ($open) $html .= '</ol></li>';
			$html .= '<li><a href="#' . $id . '">' . esc_html($text) . '</a>';
			$open = false;
			$html .= '<ol>';
			$open = true;
		} else {
			$html .= '<li><a href="#' . $id . '">' . esc_html($text) . '</a></li>';
		}
	}
	if ($open) $html .= '</ol></li>';
	$html = str_replace('<ol></ol>', '', $html);
	return $html . '</ol></details>';
}

function farhoon_cta($kind) {
	$img = get_stylesheet_directory_uri() . '/img/' . ($kind === 'kids' ? 'face.png' : 'rafiq-icon.png');
	if ($kind === 'kids') {
		$title = farhoon_t('تطبيقات فرحون للأطفال قريبًا', "Farhoon's kids apps are coming");
		$text = farhoon_t('نعلّم الصغار الصلاة والقرآن والأذكار باللعب: شخصيات محبوبة، وحركة وصوت، ونجوم ومكافآت، بلا إعلانات.', 'Teaching little ones prayer, Quran and adhkar through play: lovable characters, motion and sound, stars and rewards, with no ads.');
		$btn = farhoon_t('تعرّف على تطبيقات الأطفال', 'See our kids apps');
		$url = farhoon_lang() === 'en' ? home_url('/en/#kids') : home_url('/#kids');
	} else {
		$title = farhoon_t('جرّب رفيق الطاعة', 'Try Rafiq Al-Taa');
		$text = farhoon_t('حاسبة زكاة مفصّلة، وأذكار بعدّاد، ومواقيت وأذان، وقائمة طاعاتك اليومية. مجاني بلا إعلانات ولا حساب.', 'A detailed zakat calculator, adhkar with a counter, prayer times with adhan, and your daily deeds list. Free, no ads, no account.');
		$btn = farhoon_t('اكتشف التطبيق', 'Discover the app');
		$url = farhoon_lang() === 'en' ? home_url('/en/rafiq/') : home_url('/rafiq/');
	}
	return '<aside class="f-cta f-cta-' . $kind . '"><img src="' . esc_url($img) . '" alt="" width="72" height="72" loading="lazy"><div class="f-cta-text"><strong>' . esc_html($title) . '</strong><p>' . esc_html($text) . '</p></div><a class="f-btn" href="' . esc_url($url) . '">' . esc_html($btn) . '</a></aside>';
}

/* ---------- template helpers ---------- */

function farhoon_url($key, $lang = null) {
	$lang = $lang ?: farhoon_lang();
	$paths = ['home' => '', 'about' => 'about/', 'rafiq' => 'rafiq/', 'games' => 'games/', 'contact' => 'contact/', 'blog' => 'blog/', 'privacy' => 'rafiq/privacy/'];
	return home_url(($lang === 'en' ? '/en/' : '/') . $paths[$key]);
}

function farhoon_nav() {
	$items = ['home' => ['الرئيسية', 'Home'], 'about' => ['من نحن', 'About'], 'rafiq' => ['رفيق الطاعة', 'Rafiq Al-Taa'], 'blog' => ['المدونة', 'Blog'], 'contact' => ['تواصل معنا', 'Contact']];
	$current = (is_home() || is_archive() || is_singular(['post', 'en_post'])) ? 'blog' : '';
	echo '<nav class="f-nav" aria-label="' . esc_attr(farhoon_t('القائمة الرئيسية', 'Main menu')) . '"><input type="checkbox" id="f-menu" class="f-toggle"><label for="f-menu" class="f-burger"><span class="f-sr">' . esc_html(farhoon_t('فتح القائمة', 'Open menu')) . '</span><span></span><span></span><span></span></label><ul>';
	foreach ($items as $key => $names) {
		echo '<li><a class="' . ($key === $current ? 'on' : '') . '" href="' . esc_url(farhoon_url($key)) . '">' . esc_html(farhoon_t($names[0], $names[1])) . '</a></li>';
	}
	$alt = farhoon_alt_urls();
	$other = farhoon_lang() === 'en' ? 'ar' : 'en';
	$href = $alt[$other] ?? farhoon_url('home', $other);
	echo '<li><a class="f-lang" lang="' . $other . '" href="' . esc_url($href) . '">' . ($other === 'en' ? 'English' : 'العربية') . '</a></li></ul></nav>';
}

function farhoon_breadcrumbs() {
	$crumbs = [[farhoon_t('الرئيسية', 'Home'), farhoon_url('home')]];
	$blog_url = farhoon_lang() === 'en' ? get_post_type_archive_link('en_post') : farhoon_url('blog');
	if (is_home() || is_post_type_archive('en_post')) {
		$crumbs[] = [farhoon_t('المدونة', 'Blog'), ''];
	} elseif (is_category() || is_tax('en_category')) {
		$crumbs[] = [farhoon_t('المدونة', 'Blog'), $blog_url];
		$crumbs[] = [single_term_title('', false), ''];
	} elseif (is_singular(['post', 'en_post'])) {
		$crumbs[] = [farhoon_t('المدونة', 'Blog'), $blog_url];
		$term = farhoon_primary_term();
		if ($term) $crumbs[] = [$term->name, get_term_link($term)];
		$crumbs[] = [get_the_title(), ''];
	}
	echo '<nav class="f-crumbs" aria-label="' . esc_attr(farhoon_t('مسار التنقل', 'Breadcrumb')) . '"><ol>';
	$items = [];
	foreach ($crumbs as $i => [$name, $url]) {
		echo '<li>' . ($url ? '<a href="' . esc_url($url) . '">' . esc_html($name) . '</a>' : '<span aria-current="page">' . esc_html($name) . '</span>') . '</li>';
		$items[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => wp_strip_all_tags($name)] + ($url ? ['item' => $url] : []);
	}
	echo '</ol></nav>';
	farhoon_jsonld(['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items]);
}

function farhoon_primary_term($post = null) {
	$terms = get_the_terms($post ?: get_the_ID(), get_post_type($post) === 'en_post' ? 'en_category' : 'category');
	return ($terms && !is_wp_error($terms)) ? $terms[0] : null;
}

function farhoon_minutes($post = null) {
	$post = get_post($post);
	$m = (int) get_post_meta($post->ID, 'farhoon_minutes', true);
	if ($m) return $m;
	$words = count(preg_split('/\s+/u', trim(wp_strip_all_tags($post->post_content))));
	return max(1, (int) round($words / 200));
}

function farhoon_minutes_label($post = null) {
	$m = farhoon_minutes($post);
	return farhoon_lang() === 'en' ? $m . ' min read' : 'قراءة ' . farhoon_num($m) . ' دقائق';
}

function farhoon_num($n) {
	return farhoon_lang() === 'en' ? (string) $n : strtr((string) $n, ['0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩']);
}

function farhoon_date($post = null, $modified = false) {
	$ts = $modified ? get_post_modified_time('U', false, $post) : get_post_time('U', false, $post);
	if (farhoon_lang() === 'en') {
		// The site language is Arabic, so English month names are spelled out here.
		$months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		return wp_date('j', $ts) . ' ' . $months[(int) wp_date('n', $ts) - 1] . ' ' . wp_date('Y', $ts);
	}
	return farhoon_num(wp_date('j', $ts)) . ' ' . wp_date('F', $ts) . ' ' . farhoon_num(wp_date('Y', $ts));
}

function farhoon_card($eager = false) {
	$term = farhoon_primary_term();
	echo '<article class="f-card"><a class="f-card-link" href="' . esc_url(get_permalink()) . '"><div class="f-card-img">';
	if (has_post_thumbnail()) {
		the_post_thumbnail('farhoon-card', ['loading' => $eager ? 'eager' : 'lazy', 'sizes' => '(max-width: 700px) 100vw, 360px', 'alt' => esc_attr(get_the_title())]);
	} else {
		echo '<span class="f-card-ph"></span>';
	}
	if ($term) echo '<span class="f-pill">' . esc_html($term->name) . '</span>';
	echo '</div><div class="f-card-body"><h2 class="f-card-title">' . esc_html(get_the_title()) . '</h2><p class="f-card-ex">' . esc_html(wp_trim_words(get_the_excerpt(), 24)) . '</p></div></a>';
	echo '<div class="f-card-meta"><span>' . esc_html(farhoon_date()) . '</span><span>' . esc_html(farhoon_minutes_label()) . '</span></div></article>';
}

function farhoon_category_buttons() {
	$tax = farhoon_lang() === 'en' ? 'en_category' : 'category';
	$terms = get_terms(['taxonomy' => $tax, 'hide_empty' => true]);
	if (!$terms || is_wp_error($terms)) return;
	$all = farhoon_lang() === 'en' ? get_post_type_archive_link('en_post') : farhoon_url('blog');
	$current = (is_category() || is_tax('en_category')) ? get_queried_object_id() : 0;
	echo '<nav class="f-cats" aria-label="' . esc_attr(farhoon_t('أقسام المدونة', 'Blog categories')) . '"><a class="' . ($current ? '' : 'on') . '" href="' . esc_url($all) . '">' . esc_html(farhoon_t('كل المقالات', 'All articles')) . '</a>';
	foreach ($terms as $t) {
		if ($t->slug === 'uncategorized') continue;
		echo '<a class="' . ($current === $t->term_id ? 'on' : '') . '" href="' . esc_url(get_term_link($t)) . '">' . esc_html($t->name) . '</a>';
	}
	echo '</nav>';
}

function farhoon_share() {
	$url = rawurlencode(get_permalink());
	$title = rawurlencode(get_the_title());
	$links = [
		['WhatsApp', 'https://wa.me/?text=' . $title . '%20' . $url, 'wa'],
		['Telegram', 'https://t.me/share/url?url=' . $url . '&text=' . $title, 'tg'],
		['X', 'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title, 'x'],
		['Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' . $url, 'fb'],
		['LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' . $url, 'in'],
		[farhoon_t('البريد', 'Email'), 'mailto:?subject=' . $title . '&body=' . $url, 'em'],
	];
	echo '<section class="f-share"><h2>' . esc_html(farhoon_t('شارك هذه المقالة', 'Share this article')) . '</h2><div>';
	foreach ($links as [$name, $href, $cls]) {
		echo '<a class="f-sh f-sh-' . $cls . '" href="' . esc_url($href) . '" target="_blank" rel="noopener nofollow">' . esc_html($name) . '</a>';
	}
	echo '<button type="button" class="f-sh f-sh-copy" data-copy>' . esc_html(farhoon_t('نسخ الرابط', 'Copy link')) . '</button></div></section>';
}

// Comments wait for approval and need a name and email.
add_filter('pre_option_comment_moderation', fn() => '1');
add_filter('pre_option_require_name_email', fn() => '1');
