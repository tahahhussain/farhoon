<?php
/**
 * Google Tag Manager with Consent Mode v2. The container ID is set in Settings → Farhoon.
 * Defaults: analytics allowed, all advertising storage and signals denied everywhere; in the EU/EEA, UK and
 * Switzerland analytics storage is denied too (no banner yet), so Google only receives cookieless pings there.
 * Logged-in editors are not tracked, so our own visits do not count.
 */
defined('ABSPATH') || exit;

function farhoon_gtm_id() {
	$id = strtoupper(trim((string) get_option('farhoon_gtm_id', '')));
	return preg_match('/^GTM-[A-Z0-9]{4,10}$/', $id) ? $id : '';
}

function farhoon_track_visitor() {
	return farhoon_gtm_id() !== '' && !current_user_can('edit_posts');
}

add_action('wp_head', function () {
	if (!farhoon_track_visitor()) return;
	$id = farhoon_gtm_id();
	$eea = ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'IS', 'LI', 'NO', 'GB', 'CH'];
	// Autoptimize must leave this block alone, so consent is set before Tag Manager loads.
	echo "<!--noptimize-->
";
	?>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('consent', 'default', {ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', analytics_storage: 'granted'});
gtag('consent', 'default', {ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', analytics_storage: 'denied', region: <?php echo wp_json_encode($eea); ?>});
gtag('set', 'ads_data_redaction', true);
dataLayer.push({site_language: document.documentElement.lang || 'ar', page_type: <?php echo wp_json_encode(is_singular(['post', 'en_post']) ? 'article' : (is_front_page() ? 'home' : 'page')); ?>, content_group: <?php echo wp_json_encode(farhoon_content_group()); ?>});
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','<?php echo esc_js($id); ?>');
</script>
<!--/noptimize-->
<?php
}, 2);

add_action('wp_body_open', function () {
	if (!farhoon_track_visitor()) return;
	echo '<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=' . esc_attr(farhoon_gtm_id()) . '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>' . "\n";
});

/** The article's category slug (zakat, worship, quran…), used to compare topic clusters in reports. */
function farhoon_content_group() {
	if (is_singular(['post', 'en_post'])) {
		$t = farhoon_primary_term(get_queried_object_id());
		return $t ? $t->slug : 'blog';
	}
	if (is_front_page()) return 'home';
	if (is_page()) {
		$uri = get_page_uri(get_queried_object_id());
		return strpos($uri, 'rafiq') !== false ? 'rafiq' : 'site';
	}
	return 'blog';
}

// The events script runs on every page (Elementor pages too), only when tracking is on.
add_action('wp_enqueue_scripts', function () {
	if (!farhoon_track_visitor()) return;
	wp_enqueue_script('farhoon-track', get_stylesheet_directory_uri() . '/assets/track.js', [], FARHOON_VER, ['in_footer' => true, 'strategy' => 'defer']);
}, 101);
