<?php
/**
 * Prayer-time pages, built from the JSON in data/prayer/ (made by website/prayer-pages/build.mjs with the
 * same adhan-js library and settings as the Rafiq Al-Taa app, so the site and the app show the same times):
 *
 *   /prayer-times/                     hub: every city, today's Fajr and Maghrib
 *   /prayer-times/<country>/           the country's method, authority and cities
 *   /prayer-times/<country>/<city>/    today, this month, qibla, Hijri date, Ramadan 1448 imsakiya
 *   /ramadan-imsakiya/                 hub: expected start of Ramadan 1448, first and last day per city
 *   /prayer-times.xml                  all of the above, listed in robots.txt and in Rank Math's index
 *
 * No external calls on page view: the files are read from the theme folder.
 */
defined('ABSPATH') || exit;

const FARHOON_PT_RULES = '1.4.1';

function farhoon_pt_dir() {
	return get_stylesheet_directory() . '/data/prayer/';
}

/** Countries: authority, official timetable and how people there write dates and digits. */
function farhoon_pt_countries() {
	return [
		'saudi-arabia' => ['cc' => 'SA', 'name' => 'السعودية', 'in' => 'في السعودية', 'auth' => 'أم القرى', 'url' => 'https://www.ummulqura.org.sa/', 'months' => 'std'],
		'egypt' => ['cc' => 'EG', 'name' => 'مصر', 'in' => 'في مصر', 'auth' => 'الهيئة المصرية العامة للمساحة، وتنشرها دار الإفتاء المصرية', 'url' => 'https://www.dar-alifta.org/ar/prayer', 'months' => 'std'],
		'uae' => ['cc' => 'AE', 'name' => 'الإمارات', 'in' => 'في الإمارات', 'auth' => 'الهيئة العامة للشؤون الإسلامية والأوقاف', 'url' => 'https://www.awqaf.gov.ae/', 'months' => 'std'],
		'kuwait' => ['cc' => 'KW', 'name' => 'الكويت', 'in' => 'في الكويت', 'auth' => 'وزارة الأوقاف والشؤون الإسلامية', 'url' => 'https://www.awqaf.gov.kw/ar', 'months' => 'std'],
		'qatar' => ['cc' => 'QA', 'name' => 'قطر', 'in' => 'في قطر', 'auth' => 'وزارة الأوقاف والشؤون الإسلامية', 'url' => 'https://www.islam.gov.qa/', 'months' => 'std'],
		'bahrain' => ['cc' => 'BH', 'name' => 'البحرين', 'in' => 'في البحرين', 'auth' => 'وزارة العدل والشؤون الإسلامية والأوقاف', 'url' => 'https://www.moj.gov.bh/ar/', 'months' => 'std'],
		'oman' => ['cc' => 'OM', 'name' => 'عُمان', 'in' => 'في سلطنة عُمان', 'auth' => 'وزارة الأوقاف والشؤون الدينية', 'url' => 'https://www.mara.gov.om/', 'months' => 'std'],
		'jordan' => ['cc' => 'JO', 'name' => 'الأردن', 'in' => 'في الأردن', 'auth' => 'وزارة الأوقاف والشؤون والمقدسات الإسلامية', 'url' => 'https://www.awqaf.gov.jo/', 'months' => 'sham'],
		'morocco' => ['cc' => 'MA', 'name' => 'المغرب', 'in' => 'في المغرب', 'auth' => 'وزارة الأوقاف والشؤون الإسلامية', 'url' => 'https://www.habous.gov.ma/', 'months' => 'ma'],
		'algeria' => ['cc' => 'DZ', 'name' => 'الجزائر', 'in' => 'في الجزائر', 'auth' => 'وزارة الشؤون الدينية والأوقاف', 'url' => 'https://www.marw.dz/', 'months' => 'dz'],
		'tunisia' => ['cc' => 'TN', 'name' => 'تونس', 'in' => 'في تونس', 'auth' => 'وزارة الشؤون الدينية', 'url' => 'https://www.affaires-religieuses.tn/ar', 'months' => 'dz'],
	];
}

/** The calculation settings, in words (the same as the app's times.ts and adhan-js). */
function farhoon_pt_method($m) {
	$all = [
		'UmmAlQura' => ['أم القرى', 'الفجر عند انخفاض الشمس ١٨٫٥ درجة تحت الأفق، والعشاء بعد المغرب بـ٩٠ دقيقة'],
		'Egyptian' => ['الهيئة المصرية العامة للمساحة', 'الفجر عند ١٩٫٥ درجة تحت الأفق، والعشاء عند ١٧٫٥ درجة'],
		'Dubai' => ['الإمارات', 'الفجر والعشاء عند ١٨٫٢ درجة تحت الأفق، مع تعديل ثابت بثلاث دقائق للشروق والظهر والعصر والمغرب'],
		'Kuwait' => ['الكويت', 'الفجر عند ١٨ درجة تحت الأفق، والعشاء عند ١٧٫٥ درجة'],
		'Qatar' => ['قطر', 'الفجر عند ١٨ درجة تحت الأفق، والعشاء بعد المغرب بـ٩٠ دقيقة'],
		'MuslimWorldLeague' => ['رابطة العالم الإسلامي', 'الفجر عند ١٨ درجة تحت الأفق، والعشاء عند ١٧ درجة'],
		'Morocco' => ['المغرب', 'الفجر عند ١٩ درجة تحت الأفق، والعشاء عند ١٧ درجة'],
		'Algeria' => ['الجزائر', 'الفجر عند ١٨ درجة تحت الأفق، والعشاء عند ١٧ درجة'],
	];
	return $all[$m] ?? [$m, ''];
}

/* ---------- data ---------- */

function farhoon_pt_index() {
	static $i = null;
	if ($i === null) $i = json_decode((string) @file_get_contents(farhoon_pt_dir() . 'index.json'), true) ?: ['cities' => []];
	return $i;
}

function farhoon_pt_city($country, $city) {
	static $cache = [];
	if (!preg_match('/^[a-z-]+$/', $country . $city)) return null;
	$key = $country . '--' . $city;
	if (!array_key_exists($key, $cache)) {
		$file = farhoon_pt_dir() . $key . '.json';
		$cache[$key] = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;
	}
	return $cache[$key];
}

function farhoon_pt_cities_of($country) {
	return array_values(array_filter(farhoon_pt_index()['cities'], fn($c) => $c['country'] === $country));
}

/** Today's date in the city's time zone, and its row. */
function farhoon_pt_today($d) {
	$today = (new DateTime('now', new DateTimeZone($d['tz'])))->format('Y-m-d');
	$i = (int) round((strtotime($today . ' 12:00 UTC') - strtotime($d['first'] . ' 12:00 UTC')) / DAY_IN_SECONDS);
	$row = ($i >= 0 && isset($d['days'][$i]) && $d['days'][$i][0] === $today) ? $d['days'][$i] : null;
	return [$today, $i, $row];
}

/* ---------- formatting ---------- */

/** The Maghreb writes Western digits; elsewhere Arabic-Indic digits, as in the app. */
function farhoon_pt_n($s, $cc) {
	if (in_array($cc, ['MA', 'DZ', 'TN'], true)) return (string) $s;
	return strtr((string) $s, ['0' => '٠', '1' => '١', '2' => '٢', '3' => '٣', '4' => '٤', '5' => '٥', '6' => '٦', '7' => '٧', '8' => '٨', '9' => '٩', '.' => '٫']);
}

function farhoon_pt_time($hhmm, $cc) {
	[$h, $m] = array_map('intval', explode(':', $hhmm));
	$suffix = $h < 12 ? 'ص' : 'م';
	$h12 = $h % 12 ?: 12;
	return farhoon_pt_n($h12 . ':' . str_pad((string) $m, 2, '0', STR_PAD_LEFT), $cc) . ' ' . $suffix;
}

function farhoon_pt_months($style) {
	$m = [
		'std' => ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
		'sham' => ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'],
		'ma' => ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليوز', 'غشت', 'شتنبر', 'أكتوبر', 'نونبر', 'دجنبر'],
		'dz' => ['جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان', 'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
	];
	return $m[$style] ?? $m['std'];
}

const FARHOON_PT_HMONTHS = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
const FARHOON_PT_DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

function farhoon_pt_gdate($iso, $country, $year = true, $weekday = false) {
	$c = farhoon_pt_countries()[$country];
	[$y, $mo, $d] = array_map('intval', explode('-', $iso));
	$out = farhoon_pt_n($d, $c['cc']) . ' ' . farhoon_pt_months($c['months'])[$mo - 1] . ($year ? ' ' . farhoon_pt_n($y, $c['cc']) : '');
	if ($weekday) $out = FARHOON_PT_DAYS[(int) gmdate('w', strtotime($iso . ' 12:00 UTC'))] . ' ' . $out;
	return $out;
}

function farhoon_pt_hdate($h, $cc, $year = true) {
	[$y, $m, $d] = array_map('intval', explode('-', $h));
	return farhoon_pt_n($d, $cc) . ' ' . FARHOON_PT_HMONTHS[$m - 1] . ($year ? ' ' . farhoon_pt_n($y, $cc) . ' هـ' : '');
}

function farhoon_pt_minutes($a, $b) {
	[$h1, $m1] = array_map('intval', explode(':', $a));
	[$h2, $m2] = array_map('intval', explode(':', $b));
	return ($h2 * 60 + $m2) - ($h1 * 60 + $m1);
}

/** Arabic counted noun: 1 ساعة، 2 ساعتان، 3–10 ساعات، 11+ ساعة. */
function farhoon_pt_count($n, $forms, $cc) {
	[$one, $two, $few, $many] = $forms;
	if ($n === 1) return $one;
	if ($n === 2) return $two;
	return farhoon_pt_n($n, $cc) . ' ' . (($n % 100) >= 3 && ($n % 100) <= 10 ? $few : $many);
}

function farhoon_pt_duration($min, $cc) {
	$h = intdiv($min, 60);
	$m = $min % 60;
	$hs = farhoon_pt_count($h, ['ساعة', 'ساعتان', 'ساعات', 'ساعة'], $cc);
	return $m ? $hs . ' و' . farhoon_pt_count($m, ['دقيقة', 'دقيقتان', 'دقائق', 'دقيقة'], $cc) : $hs;
}

function farhoon_pt_direction($deg) {
	$names = ['الشمال', 'الشمال الشرقي', 'الشرق', 'الجنوب الشرقي', 'الجنوب', 'الجنوب الغربي', 'الغرب', 'الشمال الغربي'];
	return $names[((int) round($deg / 45)) % 8];
}

function farhoon_pt_url($country = '', $city = '') {
	return home_url('/prayer-times/' . ($country ? $country . '/' : '') . ($city ? $city . '/' : ''));
}

/* ---------- routing ---------- */

add_action('init', function () {
	add_rewrite_rule('^prayer-times/?$', 'index.php?farhoon_pt=hub', 'top');
	add_rewrite_rule('^prayer-times/([a-z-]+)/?$', 'index.php?farhoon_pt=country&farhoon_ptc=$matches[1]', 'top');
	add_rewrite_rule('^prayer-times/([a-z-]+)/([a-z-]+)/?$', 'index.php?farhoon_pt=city&farhoon_ptc=$matches[1]&farhoon_ptcity=$matches[2]', 'top');
	add_rewrite_rule('^ramadan-imsakiya/?$', 'index.php?farhoon_pt=imsak', 'top');
	// Not "*-sitemap.xml": Rank Math's own rule catches every address of that shape.
	add_rewrite_rule('^prayer-times\.xml$', 'index.php?farhoon_pt=sitemap', 'top');
	// New rules take effect once, without anyone having to visit Settings → Permalinks.
	if (get_option('farhoon_pt_rules') !== FARHOON_PT_RULES) {
		flush_rewrite_rules(false);
		update_option('farhoon_pt_rules', FARHOON_PT_RULES);
	}
}, 20);

add_filter('query_vars', function ($vars) {
	return array_merge($vars, ['farhoon_pt', 'farhoon_ptc', 'farhoon_ptcity']);
});

/** What is being shown: null on every other page. */
function farhoon_pt_ctx() {
	static $ctx = false;
	if ($ctx !== false) return $ctx;
	$kind = get_query_var('farhoon_pt');
	if (!$kind) return $ctx = null;
	$countries = farhoon_pt_countries();
	$country = get_query_var('farhoon_ptc');
	$city = get_query_var('farhoon_ptcity');
	$ctx = ['kind' => $kind, 'country' => $country, 'city' => $city, 'data' => null, 'ok' => true];
	if ($kind === 'country') $ctx['ok'] = isset($countries[$country]) && farhoon_pt_cities_of($country);
	if ($kind === 'city') {
		$ctx['data'] = isset($countries[$country]) ? farhoon_pt_city($country, $city) : null;
		$ctx['ok'] = (bool) $ctx['data'];
	}
	return $ctx;
}

// These addresses have no post behind them: WordPress must not treat them as the blog's front page.
add_action('parse_query', function ($q) {
	if (!$q->is_main_query() || !$q->get('farhoon_pt')) return;
	$q->is_home = false;
	$q->is_front_page = false;
	$q->is_archive = false;
	$q->is_singular = false;
	$q->is_page = false;
});
add_filter('posts_pre_query', function ($posts, $q) {
	return ($q->is_main_query() && $q->get('farhoon_pt')) ? [] : $posts;
}, 10, 2);
add_filter('redirect_canonical', function ($url) {
	return get_query_var('farhoon_pt') ? false : $url;
});

add_action('template_redirect', function () {
	$ctx = farhoon_pt_ctx();
	if (!$ctx) return;
	if ($ctx['kind'] === 'sitemap') { farhoon_pt_sitemap(); exit; }
	if (!$ctx['ok']) {
		global $wp_query;
		$wp_query->set_404();
		status_header(404);
		nocache_headers();
		return;
	}
	// One address per page: with the trailing slash, lower case.
	$path = (string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
	if (substr($path, -1) !== '/') { wp_safe_redirect(farhoon_pt_canonical(), 301); exit; }
	status_header(200);
	$GLOBALS['farhoon_campaign'] = $ctx['kind'] === 'city' ? 'prayer-' . $ctx['city'] : 'prayer-' . $ctx['kind'];
}, 5);

add_filter('template_include', function ($tpl) {
	$ctx = farhoon_pt_ctx();
	return ($ctx && $ctx['ok']) ? get_stylesheet_directory() . '/prayer.php' : $tpl;
}, 99);

add_filter('body_class', function ($c) {
	$ctx = farhoon_pt_ctx();
	if ($ctx && $ctx['ok']) $c[] = 'f-pt';
	return $c;
});

add_action('wp_enqueue_scripts', function () {
	$ctx = farhoon_pt_ctx();
	if ($ctx && $ctx['ok'] && $ctx['kind'] === 'city') {
		wp_enqueue_script('farhoon-prayer', get_stylesheet_directory_uri() . '/assets/prayer.js', [], FARHOON_VER, ['in_footer' => true, 'strategy' => 'defer']);
	}
}, 110);

/* ---------- titles, descriptions, canonical (Rank Math) ---------- */

function farhoon_pt_canonical() {
	$ctx = farhoon_pt_ctx();
	if (!$ctx) return '';
	if ($ctx['kind'] === 'imsak') return home_url('/ramadan-imsakiya/');
	if ($ctx['kind'] === 'country') return farhoon_pt_url($ctx['country']);
	if ($ctx['kind'] === 'city') return farhoon_pt_url($ctx['country'], $ctx['city']);
	return farhoon_pt_url();
}

function farhoon_pt_seo() {
	static $seo = null;
	if ($seo !== null) return $seo;
	$ctx = farhoon_pt_ctx();
	$c = farhoon_pt_countries();
	if ($ctx['kind'] === 'city') {
		$d = $ctx['data'];
		$m = farhoon_pt_method($d['method']);
		$title = $d['phrase'] . ' في ' . $d['name'] . ' اليوم وإمساكية رمضان 2027';
		$desc = $d['phrase'] . ' في ' . $d['name'] . ' اليوم وجدول الشهر كاملًا بطريقة ' . $m[0] . '، واتجاه القبلة ' . $d['qibla'] . ' درجة، وإمساكية رمضان 1448 المتوقعة، ورابط التقويم الرسمي.';
	} elseif ($ctx['kind'] === 'country') {
		$cc = $c[$ctx['country']];
		$n = count(farhoon_pt_cities_of($ctx['country']));
		$phrase = farhoon_pt_city($ctx['country'], farhoon_pt_cities_of($ctx['country'])[0]['slug'])['phrase'];
		$title = $phrase . ' ' . $cc['in'] . ' اليوم: ' . $n . ($n >= 3 && $n <= 10 ? ' مدن' : ' مدينة');
		$desc = $phrase . ' ' . $cc['in'] . ' اليوم لكل مدينة، وطريقة الحساب المعتمدة، ورابط تقويم ' . $cc['auth'] . '، وإمساكية رمضان 1448 المتوقعة.';
	} elseif ($ctx['kind'] === 'imsak') {
		$title = 'إمساكية رمضان 2027 (1448 هـ) للمدن العربية';
		$desc = 'إمساكية رمضان 1448 المتوقعة لـ' . count(farhoon_pt_index()['cities']) . ' مدينة عربية: الإمساك والفجر والإفطار وعدد ساعات الصيام، وبداية الشهر المتوقعة بحسب تقويم أم القرى.';
	} else {
		$title = 'مواقيت الصلاة اليوم في المدن العربية';
		$desc = 'مواقيت الصلاة اليوم في ' . count(farhoon_pt_index()['cities']) . ' مدينة في السعودية ومصر والخليج والأردن والمغرب العربي، بطريقة الحساب المعتمدة في كل بلد، مع القبلة وإمساكية رمضان.';
	}
	return $seo = ['title' => $title . ' | فرحون', 'h1' => $title, 'desc' => $desc];
}

add_filter('pre_get_document_title', function ($t) {
	$ctx = farhoon_pt_ctx();
	return ($ctx && $ctx['ok']) ? farhoon_pt_seo()['title'] : $t;
}, 99999);
add_filter('rank_math/frontend/title', function ($t) {
	$ctx = farhoon_pt_ctx();
	return ($ctx && $ctx['ok']) ? farhoon_pt_seo()['title'] : $t;
}, 99);
add_filter('rank_math/frontend/description', function ($t) {
	$ctx = farhoon_pt_ctx();
	return ($ctx && $ctx['ok']) ? farhoon_pt_seo()['desc'] : $t;
}, 99);
add_filter('rank_math/frontend/canonical', function ($u) {
	$ctx = farhoon_pt_ctx();
	return ($ctx && $ctx['ok']) ? farhoon_pt_canonical() : $u;
}, 99);
add_filter('rank_math/frontend/robots', function ($r) {
	$ctx = farhoon_pt_ctx();
	if (!$ctx) return $r;
	if (!$ctx['ok']) return ['index' => 'noindex', 'follow' => 'follow'];
	return array_merge(is_array($r) ? $r : [], ['index' => 'index', 'follow' => 'follow']);
}, 99);
foreach (['rank_math/opengraph/facebook/og_title', 'rank_math/opengraph/twitter/twitter_title'] as $f) {
	add_filter($f, function ($t) {
		$ctx = farhoon_pt_ctx();
		return ($ctx && $ctx['ok']) ? farhoon_pt_seo()['h1'] : $t;
	}, 99);
}
foreach (['rank_math/opengraph/facebook/og_description', 'rank_math/opengraph/twitter/twitter_description'] as $f) {
	add_filter($f, function ($t) {
		$ctx = farhoon_pt_ctx();
		return ($ctx && $ctx['ok']) ? farhoon_pt_seo()['desc'] : $t;
	}, 99);
}
add_filter('rank_math/opengraph/url', function ($u) {
	$ctx = farhoon_pt_ctx();
	return ($ctx && $ctx['ok']) ? farhoon_pt_canonical() : $u;
}, 99);

// Rank Math's own graph keeps only the site and the publisher; the page and its breadcrumbs come from here.
add_filter('rank_math/json_ld', function ($data) {
	$ctx = farhoon_pt_ctx();
	if (!$ctx || !$ctx['ok']) return $data;
	foreach ($data as $k => $node) {
		$type = is_array($node) ? ($node['@type'] ?? '') : '';
		$type = is_array($type) ? implode(',', $type) : $type;
		if (!preg_match('/WebSite|Organization/', $type)) unset($data[$k]);
	}
	return $data;
}, 100);

/* ---------- sitemap and robots.txt ---------- */

function farhoon_pt_all_urls() {
	$built = farhoon_pt_index()['built'] ?? '';
	$urls = [[farhoon_pt_url(), $built], [home_url('/ramadan-imsakiya/'), $built]];
	foreach (farhoon_pt_countries() as $slug => $c) {
		if (!farhoon_pt_cities_of($slug)) continue;
		$urls[] = [farhoon_pt_url($slug), $built];
		foreach (farhoon_pt_cities_of($slug) as $city) $urls[] = [farhoon_pt_url($slug, $city['slug']), $built];
	}
	return $urls;
}

function farhoon_pt_sitemap() {
	status_header(200);
	header('Content-Type: application/xml; charset=UTF-8');
	header('X-Robots-Tag: noindex, follow');
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach (farhoon_pt_all_urls() as [$loc, $mod]) {
		echo '<url><loc>' . esc_url($loc) . '</loc>' . ($mod ? '<lastmod>' . esc_html($mod) . '</lastmod>' : '') . '<changefreq>monthly</changefreq></url>' . "\n";
	}
	echo '</urlset>';
}

add_filter('rank_math/sitemap/index', function ($xml) {
	$mod = farhoon_pt_index()['built'] ?? '';
	return $xml . '<sitemap><loc>' . esc_url(home_url('/prayer-times.xml')) . '</loc>' . ($mod ? '<lastmod>' . esc_html($mod) . 'T00:00:00+00:00</lastmod>' : '') . '</sitemap>';
}, 11);

add_filter('robots_txt', function ($out, $public) {
	if (!$public) return $out;
	return rtrim($out) . "\nSitemap: " . home_url('/prayer-times.xml') . "\n";
}, 20, 2);

/* ---------- page parts ---------- */

function farhoon_pt_crumbs($items) {
	array_unshift($items, ['الرئيسية', home_url('/')]);
	$list = [];
	echo '<nav class="f-crumbs" aria-label="مسار التنقل"><ol>';
	foreach ($items as $i => [$name, $url]) {
		echo '<li>' . ($url ? '<a href="' . esc_url($url) . '">' . esc_html($name) . '</a>' : '<span aria-current="page">' . esc_html($name) . '</span>') . '</li>';
		$list[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $name, 'item' => $url ?: farhoon_pt_canonical()];
	}
	echo '</ol></nav>';
	return ['@type' => 'BreadcrumbList', '@id' => farhoon_pt_canonical() . '#breadcrumb', 'itemListElement' => $list];
}

/** WebPage + BreadcrumbList for this page. No FAQ: the pages have none. */
function farhoon_pt_schema($crumbs, $about = null) {
	$seo = farhoon_pt_seo();
	$page = [
		'@type' => 'WebPage',
		'@id' => farhoon_pt_canonical() . '#webpage',
		'url' => farhoon_pt_canonical(),
		'name' => $seo['h1'],
		'description' => $seo['desc'],
		'inLanguage' => 'ar',
		'isPartOf' => ['@id' => home_url('/') . '#website'],
		'breadcrumb' => ['@id' => $crumbs['@id']],
		'dateModified' => (farhoon_pt_index()['built'] ?? gmdate('Y-m-d')),
		'publisher' => ['@type' => 'Organization', 'name' => 'فرحون', 'url' => home_url('/')],
	];
	if ($about) $page['about'] = $about;
	farhoon_jsonld(['@context' => 'https://schema.org', '@graph' => [$page, $crumbs]]);
}

function farhoon_pt_names() {
	return ['fajr' => 'الفجر', 'sunrise' => 'الشروق', 'dhuhr' => 'الظهر', 'asr' => 'العصر', 'maghrib' => 'المغرب', 'isha' => 'العشاء'];
}

/** Why the times may differ by a few minutes from the local mosque. */
function farhoon_pt_why($d) {
	$c = farhoon_pt_countries()[$d['country']];
	echo '<section class="pt-sec"><h2>لماذا قد يختلف الوقت دقيقة أو دقيقتين عن مسجدك؟</h2>';
	echo '<ul class="pt-list">';
	echo '<li><strong>الاحتياط:</strong> تضيف بعض الجهات الرسمية دقائق احتياطية إلى بعض الأوقات، فيتأخر الأذان قليلًا عن الحساب الفلكي المجرد.</li>';
	echo '<li><strong>نقطة الحساب:</strong> حسبنا الأوقات لنقطة في وسط ' . esc_html($d['name']) . '، والمدن الكبيرة يمتد عرضها، فيتقدم الوقت في شرقها ويتأخر في غربها قليلًا.</li>';
	echo '<li><strong>التقريب:</strong> تُقرَّب الأوقات إلى أقرب دقيقة، وقد تقرّب جهة أخرى إلى الدقيقة التالية.</li>';
	echo '<li><strong>الأذان والإقامة:</strong> الجدول يذكر وقت الأذان (دخول الوقت)، أما الإقامة فبعده بدقائق يحددها كل مسجد.</li>';
	echo '</ul><p>المرجع عند الاختلاف هو تقويم ' . esc_html($c['auth']) . ' وأذان مسجدك. وللتفصيل في طرق الحساب وزوايا الفجر والعشاء اقرأ مقالتنا: <a href="' . esc_url(home_url('/blog/prayer-times-calculation-methods/')) . '">طرق حساب مواقيت الصلاة ولماذا تختلف بين التطبيقات والمساجد</a>.</p></section>';
}

/** The Ramadan 1448 imsakiya of a city: expected dates, the 10-minute imsak convention and fasting hours. */
function farhoon_pt_imsakiya($d) {
	if (!$d['ramadan']) return;
	$c = farhoon_pt_countries()[$d['country']];
	$cc = $d['cc'];
	$r = $d['ramadan'];
	$first = $r[0];
	$last = end($r);
	$hours = array_map(fn($x) => farhoon_pt_minutes($x[3], $x[7]), $r);
	echo '<section class="pt-sec" id="imsakiya"><h2>' . esc_html('إمساكية رمضان ' . farhoon_pt_n(1448, $cc) . ' في ' . $d['name'] . ' (متوقعة)') . '</h2>';
	echo '<p class="pt-print-row"><button type="button" class="f-btn pt-print" data-print="imsakiya">' . esc_html('اطبع إمساكية ' . $d['name']) . '</button></p>';
	echo '<p>بحسب تقويم أم القرى يُتوقع أن يبدأ رمضان ' . farhoon_pt_n(1448, $cc) . ' يوم <strong>' . esc_html(farhoon_pt_gdate($first[0], $d['country'], true, true)) . '</strong>، وكل التواريخ الهجرية في هذا الجدول متوقعة؛ لأن بداية الشهر ونهايته ' . esc_html($c['in']) . ' تتبعان إعلان رؤية الهلال، فقد يتقدم الجدول أو يتأخر يومًا.</p>';
	echo '<p>يبدأ الصيام في أول يوم مع أذان الفجر ' . esc_html(farhoon_pt_time($first[3], $cc)) . ' وينتهي مع أذان المغرب ' . esc_html(farhoon_pt_time($first[7], $cc)) . '، أي ' . esc_html(farhoon_pt_duration($hours[0], $cc)) . '، ويصير في آخر يوم ' . esc_html(farhoon_pt_duration(end($hours), $cc)) . '. أطول يوم صيام متوقع في ' . esc_html($d['name']) . ': ' . esc_html(farhoon_pt_duration(max($hours), $cc)) . '.</p>';
	echo '<p class="pt-small">الإمساك هنا قبل الفجر بـ' . esc_html(farhoon_pt_count((int) $d['imsak_before_fajr'], ['دقيقة', 'دقيقتين', 'دقائق', 'دقيقة'], $cc)) . '، وهو اصطلاح للاحتياط وليس وقتًا شرعيًا مستقلًا؛ فالأكل والشرب جائزان حتى طلوع الفجر.';
	if ($d['method'] === 'UmmAlQura') echo ' ويؤخّر تقويم أم القرى أذان العشاء في رمضان إلى ١٢٠ دقيقة بعد المغرب، أما هذا الجدول فيذكر الحساب المعتاد (٩٠ دقيقة) كما يعرضه تطبيق رفيق الطاعة، فأضف نصف ساعة إلى عمود العشاء.';
	// Say so when the clocks during Ramadan differ from today's (Morocco goes back to UTC+0 for the month).
	$offsets = array_values(array_unique(array_column($r, 9)));
	$o = (new DateTime('now', new DateTimeZone($d['tz'])))->getOffset();
	$now = 'UTC' . ($o < 0 ? '-' : '+') . intdiv(abs($o), 3600) . ((abs($o) % 3600) ? ':' . str_pad((string) ((abs($o) % 3600) / 60), 2, '0', STR_PAD_LEFT) : '');
	if (count($offsets) > 1 || $offsets[0] !== $now) {
		echo ' الجدول محسوب على التوقيت الرسمي المتوقع خلال الشهر (' . esc_html(implode('، ', $offsets)) . ')، وهو يختلف عن توقيت اليوم (' . esc_html($now) . ')؛ فإن تغيّر قرار تغيير الساعة تغيّرت الأوقات بمقدار ساعة.';
	}
	echo '</p>';
	echo '<div class="pt-scroll"><table class="pt-table pt-imsak"><thead><tr><th>رمضان</th><th>اليوم</th><th>الإمساك</th><th>الفجر</th><th>الشروق</th><th>الظهر</th><th>العصر</th><th>المغرب (الإفطار)</th><th>العشاء</th><th>ساعات الصيام</th></tr></thead><tbody>';
	foreach ($r as $i => $x) {
		echo '<tr data-date="' . esc_attr($x[0]) . '"><th scope="row">' . esc_html(farhoon_pt_n($x[1], $cc)) . '</th><td>' . esc_html(farhoon_pt_gdate($x[0], $d['country'], false, true)) . '</td>';
		for ($k = 2; $k <= 8; $k++) echo '<td>' . esc_html(farhoon_pt_time($x[$k], $cc)) . '</td>';
		echo '<td>' . esc_html(farhoon_pt_duration($hours[$i], $cc)) . '</td></tr>';
	}
	echo '</tbody></table></div></section>';
}

function farhoon_pt_other_countries($skip) {
	echo '<nav class="pt-sec pt-others" aria-label="بلدان أخرى"><h2>مواقيت الصلاة في بلدان أخرى</h2><ul class="pt-near">';
	foreach (farhoon_pt_countries() as $slug => $c) {
		if ($slug === $skip || !farhoon_pt_cities_of($slug)) continue;
		echo '<li><a href="' . esc_url(farhoon_pt_url($slug)) . '">' . esc_html($c['name']) . '</a></li>';
	}
	echo '<li><a href="' . esc_url(home_url('/ramadan-imsakiya/')) . '">إمساكية رمضان ١٤٤٨</a></li></ul></nav>';
}
