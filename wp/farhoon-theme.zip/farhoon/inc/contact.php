<?php
/**
 * Contact form: [farhoon_contact]. Each message is saved under "رسائل التواصل" in the dashboard
 * and emailed to the Farhoon inboxes. Works with page caching (no nonce; honeypot, timing and rate limit instead).
 */
defined('ABSPATH') || exit;

const FARHOON_CONTACT_TO = ['hello@farhoon.com', 'tahahussainas@gmail.com'];

add_action('init', function () {
	register_post_type('farhoon_message', [
		'labels' => [
			'name' => 'رسائل التواصل',
			'singular_name' => 'رسالة',
			'menu_name' => 'رسائل التواصل',
			'all_items' => 'كل الرسائل',
			'edit_item' => 'عرض الرسالة',
			'search_items' => 'بحث في الرسائل',
			'not_found' => 'لا توجد رسائل',
		],
		'public' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_icon' => 'dashicons-email-alt',
		'menu_position' => 25,
		'supports' => ['title', 'editor'],
		'capability_type' => 'post',
		'capabilities' => ['create_posts' => 'do_not_allow'],
		'map_meta_cap' => true,
	]);
});

// Dashboard list: who wrote, their email, the topic and the language.
add_filter('manage_farhoon_message_posts_columns', function ($cols) {
	return ['cb' => $cols['cb'], 'title' => 'الموضوع', 'f_name' => 'الاسم', 'f_email' => 'البريد', 'f_topic' => 'النوع', 'f_lang' => 'اللغة', 'date' => $cols['date']];
});
add_action('manage_farhoon_message_posts_custom_column', function ($col, $id) {
	$map = ['f_name' => '_f_name', 'f_email' => '_f_email', 'f_topic' => '_f_topic', 'f_lang' => '_f_lang'];
	if (!isset($map[$col])) return;
	$v = (string) get_post_meta($id, $map[$col], true);
	echo $col === 'f_email' ? '<a href="mailto:' . esc_attr($v) . '">' . esc_html($v) . '</a>' : esc_html($v);
}, 10, 2);
add_action('add_meta_boxes_farhoon_message', function () {
	add_meta_box('farhoon_message_details', 'بيانات المرسل', function ($post) {
		$rows = ['الاسم' => '_f_name', 'البريد' => '_f_email', 'الهاتف' => '_f_phone', 'النوع' => '_f_topic', 'اللغة' => '_f_lang', 'الصفحة' => '_f_page'];
		echo '<table class="widefat striped"><tbody>';
		foreach ($rows as $label => $key) {
			echo '<tr><th style="width:120px">' . esc_html($label) . '</th><td>' . esc_html((string) get_post_meta($post->ID, $key, true)) . '</td></tr>';
		}
		echo '</tbody></table>';
	}, 'farhoon_message', 'normal', 'high');
});

function farhoon_contact_topics() {
	return [
		'suggestion' => [farhoon_t('اقتراح ميزة أو قسم', 'Suggest a feature'), 'Suggestion'],
		'mistake' => [farhoon_t('تصحيح خطأ في المحتوى', 'Report a content mistake'), 'Mistake'],
		'support' => [farhoon_t('مشكلة في التطبيق', 'App problem'), 'Support'],
		'partner' => [farhoon_t('تعاون أو شراكة', 'Partnership'), 'Partnership'],
		'other' => [farhoon_t('موضوع آخر', 'Something else'), 'Other'],
	];
}

add_shortcode('farhoon_contact', function () {
	$en = farhoon_lang() === 'en';
	wp_enqueue_script('farhoon-contact', get_stylesheet_directory_uri() . '/assets/contact.js', [], FARHOON_VER, ['in_footer' => true, 'strategy' => 'defer']);
	$opts = '';
	foreach (farhoon_contact_topics() as $key => $names) $opts .= '<option value="' . esc_attr($key) . '">' . esc_html($names[0]) . '</option>';
	$t = fn($ar, $e) => esc_html($en ? $e : $ar);
	$action = esc_url(rest_url('farhoon/v1/contact'));
	return '<form class="f-form" method="post" action="' . $action . '" data-farhoon-contact novalidate lang="' . ($en ? 'en' : 'ar') . '" dir="' . ($en ? 'ltr' : 'rtl') . '">'
		. '<div class="f-form-row">'
		. '<label><span>' . $t('الاسم', 'Name') . ' *</span><input type="text" name="name" required maxlength="80" autocomplete="name"></label>'
		. '<label><span>' . $t('البريد الإلكتروني', 'Email') . ' *</span><input type="email" name="email" required maxlength="120" autocomplete="email" dir="ltr"></label>'
		. '</div><div class="f-form-row">'
		. '<label><span>' . $t('رقم الهاتف (اختياري)', 'Phone (optional)') . '</span><input type="tel" name="phone" maxlength="30" autocomplete="tel" dir="ltr"></label>'
		. '<label><span>' . $t('نوع الرسالة', 'Topic') . '</span><select name="topic">' . $opts . '</select></label>'
		. '</div>'
		. '<label><span>' . $t('رسالتك', 'Your message') . ' *</span><textarea name="message" required minlength="10" maxlength="4000" rows="5"></textarea></label>'
		. '<label class="f-hp" aria-hidden="true"><span>Website</span><input type="text" name="website" tabindex="-1" autocomplete="off"></label>'
		. '<input type="hidden" name="ts" value=""><input type="hidden" name="lang" value="' . ($en ? 'en' : 'ar') . '">'
		. '<p class="f-form-note">' . $t('نستخدم بياناتك للرد عليك فقط، ولا نشاركها مع أحد.', 'We only use your details to reply to you and never share them.') . '</p>'
		. '<button type="submit" class="f-btn f-btn-dark">' . $t('أرسل الرسالة', 'Send message') . '</button>'
		. '<p class="f-form-status" role="status" aria-live="polite"></p>'
		. '</form>';
});

add_action('rest_api_init', function () {
	register_rest_route('farhoon/v1', '/contact', [
		'methods' => 'POST',
		'permission_callback' => '__return_true',
		'callback' => 'farhoon_contact_submit',
	]);
});

function farhoon_contact_submit(WP_REST_Request $req) {
	$en = $req->get_param('lang') === 'en';
	$say = fn($ar, $e) => $en ? $e : $ar;
	$fail = fn($msg, $code = 400) => new WP_REST_Response(['ok' => false, 'message' => $msg], $code);

	// Bots fill the hidden field or submit within a second or two of loading the page.
	$ts = (int) $req->get_param('ts');
	if ((string) $req->get_param('website') !== '' || !$ts || (time() - $ts) < 3) {
		return new WP_REST_Response(['ok' => true, 'message' => $say('وصلت رسالتك، شكرًا لك.', 'Thank you, your message has arrived.')], 200);
	}
	$ip_key = 'farhoon_contact_' . md5((string) ($_SERVER['REMOTE_ADDR'] ?? '') . wp_salt());
	$count = (int) get_transient($ip_key);
	if ($count >= 5) return $fail($say('أرسلت رسائل كثيرة، حاول بعد ساعة.', 'Too many messages. Please try again in an hour.'), 429);

	$name = sanitize_text_field((string) $req->get_param('name'));
	$email = sanitize_email((string) $req->get_param('email'));
	$phone = sanitize_text_field((string) $req->get_param('phone'));
	$topic_key = sanitize_key((string) $req->get_param('topic'));
	$message = sanitize_textarea_field((string) $req->get_param('message'));
	$topics = farhoon_contact_topics();
	$topic = $topics[$topic_key][1] ?? 'Other';

	if (mb_strlen($name) < 2) return $fail($say('اكتب اسمك من فضلك.', 'Please enter your name.'));
	if (!is_email($email)) return $fail($say('اكتب بريدًا إلكترونيًا صحيحًا.', 'Please enter a valid email address.'));
	if (mb_strlen($message) < 10) return $fail($say('اكتب رسالتك في عشرة أحرف على الأقل.', 'Please write at least ten characters.'));
	if (substr_count($message, 'http') > 3) return $fail($say('الرسالة تحتوي روابط كثيرة.', 'The message contains too many links.'));

	$page = esc_url_raw((string) $req->get_header('referer'));
	$id = wp_insert_post([
		'post_type' => 'farhoon_message',
		'post_status' => 'private',
		'post_title' => wp_trim_words($topic . ' — ' . $name, 12, ''),
		'post_content' => $message,
	], true);
	if (is_wp_error($id)) return $fail($say('تعذّر حفظ الرسالة، حاول مرة أخرى.', 'Could not save your message. Please try again.'), 500);
	foreach (['_f_name' => $name, '_f_email' => $email, '_f_phone' => $phone, '_f_topic' => $topic, '_f_lang' => $en ? 'English' : 'العربية', '_f_page' => $page] as $k => $v) {
		update_post_meta($id, $k, $v);
	}
	set_transient($ip_key, $count + 1, HOUR_IN_SECONDS);

	$body = "رسالة جديدة من موقع فرحون\n\n"
		. "الاسم: $name\nالبريد: $email\n" . ($phone ? "الهاتف: $phone\n" : '')
		. "النوع: $topic\nاللغة: " . ($en ? 'English' : 'العربية') . "\nالصفحة: $page\n\n"
		. "الرسالة:\n$message\n\n— \nعرض في لوحة التحكم: " . admin_url('post.php?post=' . $id . '&action=edit');
	$headers = ['From: فرحون <hello@farhoon.com>', 'Reply-To: ' . $name . ' <' . $email . '>', 'Content-Type: text/plain; charset=UTF-8'];
	$sent = wp_mail(FARHOON_CONTACT_TO, '[فرحون] ' . $topic . ' — ' . $name, $body, $headers);
	update_post_meta($id, '_f_mailed', $sent ? 'yes' : 'no');

	return new WP_REST_Response(['ok' => true, 'message' => $say('وصلت رسالتك، شكرًا لك. سنرد عليك على بريدك قريبًا.', 'Thank you, your message has arrived. We will reply to your email soon.')], 200);
}
