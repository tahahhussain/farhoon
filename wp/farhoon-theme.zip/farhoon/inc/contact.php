<?php
/**
 * Contact form: [farhoon_contact]. Each message is saved under "رسائل التواصل" in the dashboard
 * and emailed to the Farhoon inboxes. Works with page caching (no nonce; honeypot, timing and rate limit instead).
 */
defined('ABSPATH') || exit;

const FARHOON_CONTACT_TO = ['hello@farhoon.com', 'tahahussainas@gmail.com'];

add_action('init', function () {
	register_post_type('farhoon_message', [
		'labels' => [
			'name' => 'رسائل التواصل',
			'singular_name' => 'رسالة',
			'menu_name' => 'رسائل التواصل',
			'all_items' => 'كل الرسائل',
			'edit_item' => 'عرض الرسالة',
			'search_items' => 'بحث في الرسائل',
			'not_found' => 'لا توجد رسائل',
		],
		'public' => false,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_icon' => 'dashicons-email-alt',
		'menu_position' => 25,
		'supports' => ['title', 'editor'],
		'capability_type' => 'post',
		'capabilities' => ['create_posts' => 'do_not_allow'],
		'map_meta_cap' => true,
	]);
});

// Dashboard list: who wrote, their email, the topic and the language.
add_filter('manage_farhoon_message_posts_columns', function ($cols) {
	return ['cb' => $cols['cb'], 'title' => 'الموضوع', 'f_name' => 'الاسم', 'f_email' => 'البريد', 'f_topic' => 'النوع', 'f_lang' => 'اللغة', 'date' => $cols['date']];
});
add_action('manage_farhoon_message_posts_custom_column', function ($col, $id) {
	$map = ['f_name' => '_f_name', 'f_email' => '_f_email', 'f_topic' => '_f_topic', 'f_lang' => '_f_lang'];
	if (!isset($map[$col])) return;
	$v = (string) get_post_meta($id, $map[$col], true);
	echo $col === 'f_email' ? '<a href="mailto:' . esc_attr($v) . '">' . esc_html($v) . '</a>' : esc_html($v);
}, 10, 2);
add_action('add_meta_boxes_farhoon_message', function () {
	add_meta_box('farhoon_message_details', 'بيانات المرسل', function ($post) {
		$rows = ['الاسم' => '_f_name', 'البريد' => '_f_email', 'الهاتف' => '_f_phone', 'النوع' => '_f_topic', 'اللغة' => '_f_lang', 'الصفحة' => '_f_page'];
		echo '<table class="widefat striped"><tbody>';
		foreach ($rows as $label => $key) {
			echo '<tr><th style="width:120px">' . esc_html($label) . '</th><td>' . esc_html((string) get_post_meta($post->ID, $key, true)) . '</td></tr>';
		}
		echo '</tbody></table>';
	}, 'farhoon_message', 'normal', 'high');
});

function farhoon_contact_topics() {
	return [
		'suggestion' => [farhoon_t('اقتراح ميزة أو قسم', 'Suggest a feature'), 'Suggestion'],
		'mistake' => [farhoon_t('تصحيح خطأ في المحتوى', 'Report a content mistake'), 'Mistake'],
		'support' => [farhoon_t('مشكلة في التطبيق', 'App problem'), 'Support'],
		'partner' => [farhoon_t('تعاون أو شراكة', 'Partnership'), 'Partnership'],
		'other' => [farhoon_t('موضوع آخر', 'Something else'), 'Other'],
	];
}

add_shortcode('farhoon_contact', function () {
	$en = farhoon_lang() === 'en';
	wp_enqueue_script('farhoon-contact', get_stylesheet_directory_uri() . '/assets/contact.js', [], FARHOON_VER, ['in_footer' => true, 'strategy' => 'defer']);
	$opts = '';
	foreach (farhoon_contact_topics() as $key => $names) $opts .= '<option value="' . esc_attr($key) . '">' . esc_html($names[0]) . '</option>';
	$t = fn($ar, $e) => esc_html($en ? $e : $ar);
	$action = esc_url(rest_url('farhoon/v1/contact'));
	return '<form class="f-form" method="post" action="' . $action . '" data-farhoon-contact novalidate lang="' . ($en ? 'en' : 'ar') . '" dir="' . ($en ? 'ltr' : 'rtl') . '">'
		. '<div class="f-form-row">'
		. '<label><span>' . $t('الاسم', 'Name') . ' *</span><input type="text" name="name" required maxlength="80" autocomplete="name"></label>'
		. '<label><span>' . $t('البريد الإلكتروني', 'Email') . ' *</span><input type="email" name="email" required maxlength="120" autocomplete="email" dir="ltr"></label>'
		. '</div><div class="f-form-row">'
		. '<label><span>' . $t('رقم الهاتف (اختياري)', 'Phone (optional)') . '</span><input type="tel" name="phone" maxlength="30" autocomplete="tel" dir="ltr"></label>'
		. '<label><span>' . $t('نوع الرسالة', 'Topic') . '</span><select name="topic">' . $opts . '</select></label>'
		. '</div>'
		. '<label><span>' . $t('رسالتك', 'Your message') . ' *</span><textarea name="message" required minlength="10" maxlength="4000" rows="5"></textarea></label>'
		. '<label class="f-hp" aria-hidden="true"><span>Website</span><input type="text" name="website" tabindex="-1" autocomplete="off"></label>'
		. '<input type="hidden" name="ts" value=""><input type="hidden" name="lang" value="' . ($en ? 'en' : 'ar') . '">'
		. '<p class="f-form-note">' . $t('نستخدم بياناتك للرد عليك فقط، ولا نشاركها مع أحد.', 'We only use your details to reply to you and never share them.') . '</p>'
		. '<button type="submit" class="f-btn f-btn-dark">' . $t('أرسل الرسالة', 'Send message') . '</button>'
		. '<p class="f-form-status" role="status" aria-live="polite"></p>'
		. '</form>';
});

add_action('rest_api_init', function () {
	register_rest_route('farhoon/v1', '/contact', [
		'methods' => 'POST',
		'permission_callback' => '__return_true',
		'callback' => 'farhoon_contact_submit',
	]);
});

function farhoon_contact_submit(WP_REST_Request $req) {
	$en = $req->get_param('lang') === 'en';
	$say = fn($ar, $e) => $en ? $e : $ar;
	$fail = fn($msg, $code = 400) => new WP_REST_Response(['ok' => false, 'message' => $msg], $code);

	// Bots fill the hidden field or submit within a second or two of loading the page.
	$ts = (int) $req->get_param('ts');
	if ((string) $req->get_param('website') !== '' || !$ts || (time() - $ts) < 3) {
		return new WP_REST_Response(['ok' => true, 'message' => $say('وصلت رسالتك، شكرًا لك.', 'Thank you, your message has arrived.')], 200);
	}
	$ip_key = 'farhoon_contact_' . md5((string) ($_SERVER['REMOTE_ADDR'] ?? '') . wp_salt());
	$count = (int) get_transient($ip_key);
	if ($count >= 5) return $fail($say('أرسلت رسائل كثيرة، حاول بعد ساعة.', 'Too many messages. Please try again in an hour.'), 429);

	$name = sanitize_text_field((string) $req->get_param('name'));
	$email = sanitize_email((string) $req->get_param('email'));
	$phone = sanitize_text_field((string) $req->get_param('phone'));
	$topic_key = sanitize_key((string) $req->get_param('topic'));
	$message = sanitize_textarea_field((string) $req->get_param('message'));
	$topics = farhoon_contact_topics();
	$topic = $topics[$topic_key][1] ?? 'Other';

	if (mb_strlen($name) < 2) return $fail($say('اكتب اسمك من فضلك.', 'Please enter your name.'));
	if (!is_email($email)) return $fail($say('اكتب بريدًا إلكترونيًا صحيحًا.', 'Please enter a valid email address.'));
	if (mb_strlen($message) < 10) return $fail($say('اكتب رسالتك في عشرة أحرف على الأقل.', 'Please write at least ten characters.'));
	if (substr_count($message, 'http') > 3) return $fail($say('الرسالة تحتوي روابط كثيرة.', 'The message contains too many links.'));

	$page = esc_url_raw((string) $req->get_header('referer'));
	$id = wp_insert_post([
		'post_type' => 'farhoon_message',
		'post_status' => 'private',
		'post_title' => wp_trim_words($topic . ' — ' . $name, 12, ''),
		'post_content' => $message,
	], true);
	if (is_wp_error($id)) return $fail($say('تعذّر حفظ الرسالة، حاول مرة أخرى.', 'Could not save your message. Please try again.'), 500);
	foreach (['_f_name' => $name, '_f_email' => $email, '_f_phone' => $phone, '_f_topic' => $topic, '_f_lang' => $en ? 'English' : 'العربية', '_f_page' => $page] as $k => $v) {
		update_post_meta($id, $k, $v);
	}
	set_transient($ip_key, $count + 1, HOUR_IN_SECONDS);

	$fields = ['name' => $name, 'email' => $email, 'phone' => $phone, 'topic' => $topics[$topic_key][0] ?? $topic, 'lang' => $en ? 'English' : 'العربية', 'page' => $page, 'message' => $message, 'id' => $id];
	$sent = farhoon_contact_send($fields, $topic);
	update_post_meta($id, '_f_mailed', $sent ? 'yes' : 'no');

	return new WP_REST_Response(['ok' => true, 'message' => $say('وصلت رسالتك، شكرًا لك. سنرد عليك على بريدك قريبًا.', 'Thank you, your message has arrived. We will reply to your email soon.')], 200);
}


/* ---------- the email to the Farhoon team ---------- */

function farhoon_contact_send(array $f, $topic_en) {
	$admin = admin_url('post.php?post=' . $f['id'] . '&action=edit');
	$plain = "رسالة جديدة من موقع فرحون

الاسم: {$f['name']}
البريد: {$f['email']}
" . ($f['phone'] ? "الهاتف: {$f['phone']}
" : '')
		. "النوع: {$f['topic']}
اللغة: {$f['lang']}
الصفحة: {$f['page']}

الرسالة:
{$f['message']}

عرض في لوحة التحكم: $admin";
	// The envelope sender must be on farhoon.com so SPF and DKIM pass; Gmail drops mail that fails both.
	$setup = function ($mailer) use ($plain) {
		$mailer->Sender = 'hello@farhoon.com';
		$mailer->AltBody = $plain;
		$mailer->CharSet = 'UTF-8';
	};
	add_action('phpmailer_init', $setup);
	$headers = [
		'From: فرحون <hello@farhoon.com>',
		'Reply-To: ' . $f['name'] . ' <' . $f['email'] . '>',
		'Content-Type: text/html; charset=UTF-8',
	];
	$sent = wp_mail(FARHOON_CONTACT_TO, 'رسالة جديدة: ' . $f['topic'] . ' — ' . $f['name'], farhoon_contact_email_html($f, $admin), $headers);
	remove_action('phpmailer_init', $setup);
	return $sent;
}

function farhoon_contact_email_html(array $f, $admin) {
	$e = fn($v) => esc_html($v);
	$logo = esc_url(get_stylesheet_directory_uri() . '/img/logo-dark.png');
	$when = wp_date('j F Y، g:i a');
	$reply = 'mailto:' . rawurlencode($f['email']) . '?subject=' . rawurlencode('رد من فرحون: ' . $f['topic']);
	$row = function ($label, $value, $link = '') use ($e) {
		if ($value === '') return '';
		// Emails, phone numbers and links read left to right even inside Arabic text.
		$v = $link ? '<a href="' . esc_url($link) . '" dir="ltr" style="color:#1B1446;font-weight:bold;text-decoration:none;unicode-bidi:embed;' . (strpos($link, 'tel:') === 0 ? 'white-space:nowrap' : 'word-break:break-all') . '">' . $e($value) . '</a>' : $e($value);
		return '<tr><td style="padding:10px 14px;color:#5B6478;font-size:14px;width:90px;border-bottom:1px solid #F0E6CF;vertical-align:top">' . $e($label) . '</td>'
			. '<td style="padding:10px 14px;color:#24324A;font-size:15px;border-bottom:1px solid #F0E6CF;word-break:break-word">' . $v . '</td></tr>';
	};
	return '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>رسالة جديدة</title></head>'
		. '<body style="margin:0;padding:0;background:#F4F0E6;font-family:Tahoma,Arial,sans-serif;direction:rtl">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F4F0E6;width:100%"><tr><td align="center" style="padding:24px 12px">'
		. '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#FFFFFF;border-radius:18px;overflow:hidden;border:1px solid #EDE3CC">'
		// Header
		. '<tr><td style="background:#1B1446;padding:22px 28px;text-align:right">'
		. '<img src="' . $logo . '" width="110" alt="فرحون" style="display:block;border:0;margin:0 0 12px auto">'
		. '<div style="color:#FFC531;font-size:13px;font-weight:bold;letter-spacing:.3px">نموذج التواصل · farhoon.com</div>'
		. '<div style="color:#FFFFFF;font-size:22px;font-weight:bold;margin-top:4px">رسالة جديدة من ' . $e($f['name']) . '</div>'
		. '</td></tr>'
		// Topic and time
		. '<tr><td style="padding:20px 28px 6px;text-align:right">'
		. '<span style="display:inline-block;background:#FFC531;color:#1B1446;font-weight:bold;font-size:13px;padding:5px 14px;border-radius:99px">' . $e($f['topic']) . '</span>'
		. '<span style="color:#8A90A0;font-size:13px;margin-right:10px">' . $e($when) . '</span>'
		. '</td></tr>'
		// Message
		. '<tr><td style="padding:14px 28px 4px;text-align:right">'
		. '<div style="color:#1B1446;font-size:15px;font-weight:bold;margin-bottom:8px">الرسالة</div>'
		. '<div style="background:#FFF8E6;border-right:4px solid #FFC531;border-radius:10px;padding:16px 18px;color:#24324A;font-size:16px;line-height:1.9;">' . nl2br($e($f['message'])) . '</div>'
		. '</td></tr>'
		// Sender details
		. '<tr><td style="padding:20px 28px 4px;text-align:right">'
		. '<div style="color:#1B1446;font-size:15px;font-weight:bold;margin-bottom:8px">بيانات المرسل</div>'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #F0E6CF;border-radius:12px;border-collapse:separate;overflow:hidden">'
		. $row('الاسم', $f['name']) . $row('البريد', $f['email'], 'mailto:' . $f['email']) . $row('الهاتف', $f['phone'], $f['phone'] ? 'tel:' . preg_replace('/[^0-9+]/', '', $f['phone']) : '')
		. $row('اللغة', $f['lang']) . $row('الصفحة', $f['page'], $f['page'])
		. '</table></td></tr>'
		// Actions
		. '<tr><td style="padding:22px 28px 26px;text-align:right">'
		. '<a href="' . esc_url($reply) . '" style="display:inline-block;background:#1B1446;color:#FFFFFF;font-weight:bold;font-size:15px;text-decoration:none;padding:12px 22px;border-radius:12px;margin-left:8px">الرد على ' . $e($f['name']) . '</a>'
		. '<a href="' . esc_url($admin) . '" style="display:inline-block;background:#FFFFFF;color:#1B1446;font-weight:bold;font-size:15px;text-decoration:none;padding:10px 20px;border-radius:12px;border:2px solid #1B1446">افتح في لوحة التحكم</a>'
		. '</td></tr>'
		// Footer
		. '<tr><td style="background:#FBF7EC;padding:14px 28px;text-align:center;color:#8A90A0;font-size:12px;line-height:1.7">'
		. 'وصلتك هذه الرسالة من نموذج التواصل في <a href="https://farhoon.com" style="color:#1E5B46;text-decoration:none">farhoon.com</a>. الرد على هذا البريد يذهب إلى المرسل مباشرة.'
		. '</td></tr>'
		. '</table></td></tr></table></body></html>';
}
