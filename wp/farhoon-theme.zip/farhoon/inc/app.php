<?php
/**
 * Rafiq Al-Taa on Google Play: one switch (Settings → Farhoon) turns every "coming soon" into a Play button.
 * Store links carry UTM tags in Play's `referrer`, so Play Console shows store visits and installs per page
 * without any tracking code in the app or cookies on the site.
 */
defined('ABSPATH') || exit;

const FARHOON_PLAY_ID = 'com.rafiqaltaa.app';

function farhoon_rafiq_live() {
	return (bool) get_option('farhoon_rafiq_live', false);
}

/** Play store link with campaign tags. $medium: site area (blog, page, bio…); $campaign: page slug; $content: button spot. */
function farhoon_play_url($medium = 'site', $campaign = '', $content = '') {
	$ref = ['utm_source' => 'farhoon.com', 'utm_medium' => $medium];
	if ($campaign !== '') $ref['utm_campaign'] = $campaign;
	if ($content !== '') $ref['utm_content'] = $content;
	$hl = farhoon_lang() === 'en' ? 'en' : 'ar';
	return 'https://play.google.com/store/apps/details?id=' . FARHOON_PLAY_ID . '&hl=' . $hl . '&referrer=' . rawurlencode(http_build_query($ref));
}

/** Slug of the page or article being shown, used as the campaign name. */
function farhoon_campaign() {
	// Pages without a post behind them (the prayer-time pages) name their own campaign.
	if (!empty($GLOBALS['farhoon_campaign'])) return $GLOBALS['farhoon_campaign'];
	$o = get_queried_object();
	if ($o instanceof WP_Post) return $o->post_name;
	return is_front_page() ? 'home' : 'other';
}

/** The store button, or the "coming soon" line before the app is public. */
function farhoon_play_button($content = 'button', $class = 'f-btn f-btn-play') {
	if (!farhoon_rafiq_live()) {
		return '<span class="f-soon">' . esc_html(farhoon_t('قريبًا على Google Play', 'Coming soon to Google Play')) . '</span>';
	}
	$medium = is_singular(['post', 'en_post']) ? 'blog' : 'page';
	return '<a class="' . esc_attr($class) . '" href="' . esc_url(farhoon_play_url($medium, farhoon_campaign(), $content)) . '" rel="noopener" data-cta="' . esc_attr($content) . '">'
		. '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path fill="currentColor" d="M7 4l13 8-13 8z"/></svg>'
		. esc_html(farhoon_t('حمّله من Google Play', 'Get it on Google Play')) . '</a>';
}

// [farhoon_play] for Elementor text and page content.
add_shortcode('farhoon_play', function ($atts) {
	$a = shortcode_atts(['spot' => 'page'], $atts);
	return farhoon_play_button($a['spot']);
});

// farhoon.com/get/rafiq/ (bio links, video descriptions, QR codes): straight to the store once public.
// ?s=<source> names the source, e.g. /get/rafiq/?s=tiktok
add_action('template_redirect', function () {
	$path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
	if ($path !== 'get/rafiq') return;
	$src = isset($_GET['s']) ? sanitize_key(wp_unslash($_GET['s'])) : 'direct';
	nocache_headers();
	if (farhoon_rafiq_live()) {
		$ref = rawurlencode(http_build_query(['utm_source' => $src ?: 'direct', 'utm_medium' => 'shortlink', 'utm_campaign' => 'get-rafiq']));
		wp_redirect('https://play.google.com/store/apps/details?id=' . FARHOON_PLAY_ID . '&referrer=' . $ref, 302);
	} else {
		wp_redirect(home_url('/rafiq/'), 302);
	}
	exit;
}, 1);

// Settings → Farhoon: the switch.
add_action('admin_menu', function () {
	add_options_page('Farhoon', 'فرحون', 'manage_options', 'farhoon', function () {
		if (isset($_POST['farhoon_save']) && check_admin_referer('farhoon_settings')) {
			update_option('farhoon_rafiq_live', !empty($_POST['farhoon_rafiq_live']));
			update_option('farhoon_app_sha256', strtoupper(preg_replace('/[^A-Fa-f0-9:]/', '', wp_unslash($_POST['farhoon_app_sha256'] ?? ''))));
			update_option('farhoon_gtm_id', strtoupper(sanitize_text_field(wp_unslash($_POST['farhoon_gtm_id'] ?? ''))));
			if (class_exists('\Elementor\Plugin')) \Elementor\Plugin::$instance->files_manager->clear_cache();
			echo '<div class="notice notice-success"><p>تم الحفظ. امسح ذاكرة NGINX المؤقتة لتظهر الأزرار للزوار فورًا.</p></div>';
		}
		echo '<div class="wrap"><h1>إعدادات فرحون</h1><form method="post">';
		wp_nonce_field('farhoon_settings');
		echo '<label><input type="checkbox" name="farhoon_rafiq_live" value="1" ' . checked(farhoon_rafiq_live(), true, false) . '> رفيق الطاعة منشور للجميع على Google Play (يُظهر أزرار التحميل في كل الموقع ويفعّل الرابط farhoon.com/get/rafiq/)</label>';
		echo '<p><label>معرّف Google Tag Manager: <input type="text" name="farhoon_gtm_id" value="' . esc_attr(get_option('farhoon_gtm_id', '')) . '" placeholder="GTM-XXXXXXX" style="direction:ltr;width:160px"></label> (اتركه فارغًا لإيقاف التتبع. زيارات المحررين المسجلين لا تُحسب.)</p>';
		echo '<p><label>بصمة SHA-256 لشهادة توقيع التطبيق في Google Play (Play Console ← سلامة التطبيق ← توقيع التطبيق): <br><input type="text" name="farhoon_app_sha256" value="' . esc_attr(get_option('farhoon_app_sha256', '')) . '" placeholder="AB:CD:…" style="direction:ltr;width:100%;max-width:760px"></label><br>تُنشر في <code>/.well-known/assetlinks.json</code> لربط الموقع بالتطبيق (App Links).</p>';
		echo '<p>رابط المتجر: <code>' . esc_html('https://play.google.com/store/apps/details?id=' . FARHOON_PLAY_ID) . '</code></p>';
		echo '<p><button class="button button-primary" name="farhoon_save" value="1">حفظ</button></p></form></div>';
	});
});

// Digital Asset Links: lets Android open farhoon.com links in the Rafiq app once the app declares App Links.
add_action('init', function () {
	$path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
	if ($path !== '.well-known/assetlinks.json') return;
	$fps = array_filter(array_map('trim', explode(',', (string) get_option('farhoon_app_sha256', ''))));
	if (!$fps) return; // nothing to declare yet: WordPress shows its normal 404
	nocache_headers();
	header('Content-Type: application/json');
	header('Access-Control-Allow-Origin: *');
	echo wp_json_encode([[
		'relation' => ['delegate_permission/common.handle_all_urls'],
		'target' => ['namespace' => 'android_app', 'package_name' => FARHOON_PLAY_ID, 'sha256_cert_fingerprints' => array_values($fps)],
	]], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
	exit;
}, 0);
