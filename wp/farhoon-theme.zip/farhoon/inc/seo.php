<?php
/**
 * SEO details Rank Math does not cover the way we need: a sharing image on every page, the editorial team
 * as author, no Article schema on plain pages, the app's own MobileApplication data, and HSTS.
 */
defined('ABSPATH') || exit;

// Pages without their own image still get a picture when shared on WhatsApp, Facebook or X.
add_action('wp_head', function () {
	if (is_singular(['post', 'en_post']) && has_post_thumbnail()) return;
	$uri = is_page() ? get_page_uri(get_queried_object_id()) : '';
	$file = in_array($uri, ['rafiq', 'en/rafiq', 'rafiq/support', 'rafiq/terms'], true) && file_exists(get_stylesheet_directory() . '/img/og-rafiq.png') ? 'og-rafiq.png' : 'og-farhoon.png';
	$img = get_stylesheet_directory_uri() . '/img/' . $file;
	echo '<meta property="og:image" content="' . esc_url($img) . '">' . "\n";
	echo '<meta property="og:image:width" content="1200">' . "\n" . '<meta property="og:image:height" content="630">' . "\n";
	echo '<meta property="og:image:alt" content="' . esc_attr(farhoon_t('فرحون: تطبيقات عربية نافعة للأسرة', 'Farhoon: useful Arabic apps for families')) . '">' . "\n";
	echo '<meta name="twitter:image" content="' . esc_url($img) . '">' . "\n";
}, 6);

function farhoon_team_url() {
	return home_url(farhoon_lang() === 'en' ? '/team/' : '/team/');
}

// Author in structured data: the editorial team page, not the WordPress login name.
add_filter('rank_math/json_ld', function ($data) {
	$team = ['@type' => 'Organization', 'name' => farhoon_t('فريق تحرير فرحون', 'Farhoon editorial team'), 'url' => farhoon_team_url()];
	$fix = function (&$node) use (&$fix, $team) {
		if (!is_array($node)) return;
		if (isset($node['author']) && is_array($node['author'])) $node['author'] = $team;
		foreach ($node as &$child) if (is_array($child)) $fix($child);
	};
	foreach ($data as $key => &$entity) {
		if (!is_array($entity)) continue;
		$type = $entity['@type'] ?? '';
		// The login name must not appear as a person.
		if ($type === 'Person' || $key === 'ProfilePage') { unset($data[$key]); continue; }
		// Plain pages are web pages, not articles.
		if (is_page() && in_array($type, ['Article', 'BlogPosting', 'NewsArticle'], true)) { unset($data[$key]); continue; }
		$fix($entity);
	}
	return $data;
}, 99);

// Hide "written by admin" in X cards.
add_filter('rank_math/opengraph/twitter/twitter_data1', '__return_empty_string');
add_filter('rank_math/opengraph/twitter/twitter_label1', '__return_empty_string');

// The app page describes the app itself.
add_action('wp_head', function () {
	if (!is_page()) return;
	$uri = get_page_uri(get_queried_object_id());
	if ($uri !== 'rafiq' && $uri !== 'en/rafiq') return;
	$en = $uri === 'en/rafiq';
	$app = [
		'@context' => 'https://schema.org',
		'@type' => 'MobileApplication',
		'name' => $en ? 'Rafiq Al-Taa' : 'رفيق الطاعة',
		'alternateName' => $en ? 'رفيق الطاعة: قرآن وأذان' : 'Rafiq Al-Taa',
		'operatingSystem' => 'Android',
		'applicationCategory' => 'LifestyleApplication',
		'inLanguage' => 'ar',
		'description' => $en
			? 'A free Islamic app with no ads and no account: Madinah Mushaf with offline tafsir, prayer times and adhan that works with the app closed, adhkar, zakat calculator, daily deeds and Hijri calendar.'
			: 'تطبيق إسلامي مجاني بلا إعلانات ولا حساب: مصحف المدينة مع تفسير يعمل بدون إنترنت، ومواقيت الصلاة وأذان يعمل والتطبيق مغلق، والأذكار، وحاسبة الزكاة، وطاعاتي اليومية، والتقويم الهجري.',
		'url' => home_url('/' . $uri . '/'),
		'image' => get_stylesheet_directory_uri() . '/img/rafiq-icon.png',
		'offers' => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD'],
		'publisher' => ['@type' => 'Organization', 'name' => 'Farhoon', 'alternateName' => 'فرحون', 'url' => home_url('/')],
	];
	if (farhoon_rafiq_live()) {
		$app['installUrl'] = 'https://play.google.com/store/apps/details?id=' . FARHOON_PLAY_ID;
		$app['downloadUrl'] = $app['installUrl'];
	}
	farhoon_jsonld($app);
}, 20);

// Browsers keep to HTTPS for a year (subdomains are left out on purpose).
add_filter('wp_headers', function ($headers) {
	if (is_ssl()) $headers['Strict-Transport-Security'] = 'max-age=31536000';
	return $headers;
}, 20);
