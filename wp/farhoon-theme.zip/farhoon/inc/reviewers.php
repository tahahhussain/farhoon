<?php
/**
 * "Reviewed by" for articles: a scholar or expert reviewer's name, credential, profile link and review date.
 * Set in the article edit screen (box «المراجعة الشرعية»). Shown under the title and added to the
 * structured data as reviewedBy / lastReviewed on the WebPage. Nothing shows until a reviewer is set.
 */
defined('ABSPATH') || exit;

const FARHOON_REVIEW_KEYS = ['farhoon_reviewer', 'farhoon_reviewer_title', 'farhoon_reviewer_url', 'farhoon_reviewed'];

add_action('init', function () {
	foreach (FARHOON_REVIEW_KEYS as $k) {
		foreach (['post', 'en_post'] as $type) register_post_meta($type, $k, ['show_in_rest' => true, 'single' => true, 'type' => 'string', 'auth_callback' => fn() => current_user_can('edit_posts')]);
	}
});

add_action('add_meta_boxes', function () {
	foreach (['post', 'en_post'] as $type) {
		add_meta_box('farhoon_review', 'المراجعة الشرعية', function ($post) {
			wp_nonce_field('farhoon_review', 'farhoon_review_nonce');
			$v = fn($k) => esc_attr(get_post_meta($post->ID, $k, true));
			echo '<p><label>اسم المراجع<br><input type="text" name="farhoon_reviewer" value="' . $v('farhoon_reviewer') . '" style="width:100%"></label></p>';
			echo '<p><label>صفته (مثل: ماجستير الفقه المقارن، جامعة الأزهر)<br><input type="text" name="farhoon_reviewer_title" value="' . $v('farhoon_reviewer_title') . '" style="width:100%"></label></p>';
			echo '<p><label>رابط يعرّف به (اختياري)<br><input type="url" name="farhoon_reviewer_url" value="' . $v('farhoon_reviewer_url') . '" style="width:100%;direction:ltr"></label></p>';
			echo '<p><label>تاريخ المراجعة<br><input type="date" name="farhoon_reviewed" value="' . $v('farhoon_reviewed') . '"></label></p>';
			echo '<p style="color:#666">يظهر تحت عنوان المقالة: «راجعه: الاسم، الصفة، التاريخ» بعد موافقة المراجع على نشر اسمه.</p>';
		}, $type, 'side');
	}
});

add_action('save_post', function ($id) {
	if (!isset($_POST['farhoon_review_nonce']) || !wp_verify_nonce($_POST['farhoon_review_nonce'], 'farhoon_review')) return;
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
	if (!current_user_can('edit_post', $id)) return;
	update_post_meta($id, 'farhoon_reviewer', sanitize_text_field(wp_unslash($_POST['farhoon_reviewer'] ?? '')));
	update_post_meta($id, 'farhoon_reviewer_title', sanitize_text_field(wp_unslash($_POST['farhoon_reviewer_title'] ?? '')));
	update_post_meta($id, 'farhoon_reviewer_url', esc_url_raw(wp_unslash($_POST['farhoon_reviewer_url'] ?? '')));
	$date = sanitize_text_field(wp_unslash($_POST['farhoon_reviewed'] ?? ''));
	update_post_meta($id, 'farhoon_reviewed', preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : '');
});

/** The reviewer of an article, or null. */
function farhoon_review($post = null) {
	$id = get_post($post)->ID ?? 0;
	$name = trim((string) get_post_meta($id, 'farhoon_reviewer', true));
	if ($name === '') return null;
	return [
		'name' => $name,
		'title' => trim((string) get_post_meta($id, 'farhoon_reviewer_title', true)),
		'url' => (string) get_post_meta($id, 'farhoon_reviewer_url', true),
		'date' => (string) get_post_meta($id, 'farhoon_reviewed', true),
	];
}

/** Line under the title: «راجعه: الاسم، الصفة · ٢٥ نوفمبر ٢٠٢٦». */
function farhoon_review_line() {
	$r = farhoon_review();
	if (!$r) return;
	$name = $r['url'] ? '<a href="' . esc_url($r['url']) . '" rel="noopener" target="_blank">' . esc_html($r['name']) . '</a>' : esc_html($r['name']);
	$when = $r['date'] ? ' · <time datetime="' . esc_attr($r['date']) . '">' . esc_html(farhoon_lang() === 'en' ? wp_date('j F Y', strtotime($r['date'])) : farhoon_num(wp_date('j', strtotime($r['date']))) . ' ' . wp_date('F', strtotime($r['date'])) . ' ' . farhoon_num(wp_date('Y', strtotime($r['date'])))) . '</time>' : '';
	echo '<span class="f-meta-i f-meta-review">' . esc_html(farhoon_t('راجعه: ', 'Reviewed by: ')) . $name . ($r['title'] ? '، ' . esc_html($r['title']) : '') . $when . '</span>';
}

// Structured data: reviewedBy and lastReviewed on the article's WebPage.
add_filter('rank_math/json_ld', function ($data) {
	if (!is_singular(['post', 'en_post'])) return $data;
	$r = farhoon_review(get_queried_object_id());
	if (!$r) return $data;
	$person = array_filter(['@type' => 'Person', 'name' => $r['name'], 'jobTitle' => $r['title'] ?: null, 'url' => $r['url'] ?: null]);
	foreach ($data as $k => &$node) {
		if (is_array($node) && ($node['@type'] ?? '') === 'WebPage') {
			$node['reviewedBy'] = $person;
			if ($r['date']) $node['lastReviewed'] = $r['date'];
		}
	}
	return $data;
}, 100);
