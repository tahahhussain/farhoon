<?php
/**
 * Tools → مقالات فرحون: imports the articles published in the GitHub repository (wp/articles-new/)
 * with their 4 images, SEO fields, FAQ, schema and call-to-action text. One article per request, so the
 * server time limit is never reached. Articles are created as drafts unless "publish" is chosen; running
 * it again updates the same articles (matched by address) and reuses images already uploaded.
 * English versions (index entry key "en": "NN-slug.en.json") become en_post articles in en_category,
 * paired with the Arabic article through the meta farhoon_pair, both ways.
 */
defined('ABSPATH') || exit;

// Raw files from the repository: available as soon as they are pushed (GitHub Pages can lag or stall).
const FARHOON_SRC = 'https://raw.githubusercontent.com/tahahhussain/farhoon/main/';

function farhoon_fetch_json($path) {
	$r = wp_remote_get(FARHOON_SRC . $path . '?v=' . time(), ['timeout' => 60]);
	if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return null;
	return json_decode(wp_remote_retrieve_body($r), true);
}

/** Uploads one image once (remembered by file name) and returns its attachment ID. */
function farhoon_image($file, $alt, $caption, $post_id, $set_text = true) {
	$found = get_posts(['post_type' => 'attachment', 'post_status' => 'inherit', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => 'farhoon_source', 'meta_value' => $file]);
	if ($found) {
		$id = $found[0];
	} else {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$tmp = download_url(FARHOON_SRC . 'assets/blog/' . rawurlencode($file), 60);
		if (is_wp_error($tmp)) return $tmp;
		$id = media_handle_sideload(['name' => $file, 'tmp_name' => $tmp], $post_id, $alt);
		if (is_wp_error($id)) { @unlink($tmp); return $id; }
		update_post_meta($id, 'farhoon_source', $file);
	}
	// An attachment shared by both languages keeps the Arabic text; English pages pass their own alt.
	if ($set_text || !$found) {
		update_post_meta($id, '_wp_attachment_image_alt', $alt);
		if ($caption !== '') wp_update_post(['ID' => $id, 'post_excerpt' => $caption]);
	}
	return (int) $id;
}

/** English category: found by name or address, created the first time. */
function farhoon_en_term($name) {
	$name = trim((string) $name) ?: 'Worship';
	$t = get_term_by('name', $name, 'en_category') ?: get_term_by('slug', sanitize_title($name), 'en_category');
	if ($t) return (int) $t->term_id;
	$new = wp_insert_term($name, 'en_category', ['slug' => sanitize_title($name)]);
	return is_wp_error($new) ? 0 : (int) $new['term_id'];
}

/** Links an Arabic article and its English version both ways (they share the article number). */
function farhoon_pair_by_number($id, $type, $number) {
	if (!$number) return;
	$other = get_posts(['post_type' => $type === 'post' ? 'en_post' : 'post', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => 'farhoon_number', 'meta_value' => (string) $number]);
	if (!$other) return;
	update_post_meta($id, 'farhoon_pair', (string) $other[0]);
	update_post_meta($other[0], 'farhoon_pair', (string) $id);
}

function farhoon_import_one($file, $status) {
	$d = farhoon_fetch_json('wp/articles-new/' . $file);
	if (!$d) return ['ok' => false, 'msg' => "تعذّر تنزيل $file"];
	$en = (bool) preg_match('/\.en\.json$/', $file);
	$type = $en ? 'en_post' : 'post';
	$cats = ['الزكاة' => 'zakat', 'العبادات والأذكار' => 'worship', 'تربية الأطفال' => 'kids', 'القرآن والتجويد' => 'quran', 'تطبيقات إسلامية' => 'islamic-apps'];
	$existing = get_page_by_path($d['slug'], OBJECT, $type);
	$post = ['post_type' => $type, 'post_title' => $d['title'], 'post_name' => $d['slug'], 'post_excerpt' => $d['excerpt'], 'post_content' => '', 'comment_status' => 'open'];
	if ($existing) {
		$post['ID'] = $existing->ID;
		// A published article stays published; a draft becomes what was asked.
		$post['post_status'] = $existing->post_status === 'publish' ? 'publish' : $status;
		$id = wp_update_post(wp_slash($post), true);
	} else {
		$post['post_status'] = $status;
		$id = wp_insert_post(wp_slash($post), true);
	}
	if (is_wp_error($id)) return ['ok' => false, 'msg' => $d['slug'] . ': ' . $id->get_error_message()];

	// Images: the first is the featured image, the others replace <!--IMG:n--> in the text.
	$content = $d['content_html'];
	$errors = [];
	foreach (($d['images'] ?? []) as $i => $im) {
		$att = farhoon_image($im['file'], $im['alt'], $im['caption'] ?? '', $id, !$en);
		if (is_wp_error($att)) { $errors[] = $im['file']; continue; }
		if ($i === 0) { set_post_thumbnail($id, $att); continue; }
		$img = wp_get_attachment_image($att, 'large', false, ['loading' => 'lazy', 'decoding' => 'async', 'alt' => $im['alt'], 'sizes' => '(max-width: 900px) 100vw, 860px']);
		$fig = '<figure class="f-fig">' . $img . (!empty($im['caption']) ? '<figcaption>' . esc_html($im['caption']) . '</figcaption>' : '') . '</figure>';
		$content = preg_replace('#(?:<p>\s*)?<!--\s*IMG:' . ($i + 1) . '\s*-->(?:\s*</p>)?#', $fig, $content, 1);
	}
	$content = preg_replace('#<!--\s*IMG:\d+\s*-->#', '', $content);
	wp_update_post(wp_slash(['ID' => $id, 'post_content' => $content]));

	if ($en) wp_set_object_terms($id, array_filter([farhoon_en_term($d['category'] ?? '')]), 'en_category');
	else wp_set_object_terms($id, [$cats[$d['category']] ?? 'worship'], 'category');
	$keywords = [$d['focus_keyword']];
	foreach ($d['keywords'] ?? [] as $k) {
		if (count($keywords) >= 5) break;
		if ($k['keyword'] !== $d['focus_keyword'] && in_array($k['type'], ['primary', 'secondary', 'long-tail'], true)) $keywords[] = $k['keyword'];
	}
	update_post_meta($id, 'rank_math_title', $d['meta_title']);
	update_post_meta($id, 'rank_math_description', $d['meta_description']);
	update_post_meta($id, 'rank_math_focus_keyword', implode(',', $keywords));
	update_post_meta($id, 'rank_math_twitter_use_facebook', 'on');
	update_post_meta($id, 'rank_math_schema_BlogPosting', [
		'@type' => 'BlogPosting',
		'metadata' => ['title' => 'Article', 'type' => 'template', 'isPrimary' => true, 'reviewLocationShortcode' => '[rank_math_rich_snippet]', 'name' => 'Article'],
		'headline' => '%seo_title%', 'description' => '%seo_description%', 'keywords' => '%keywords%',
		'articleSection' => '%primary_taxonomy_terms%',
		'datePublished' => '%date(Y-m-d\TH:i:sP)%', 'dateModified' => '%modified(Y-m-d\TH:i:sP)%',
		'author' => ['@type' => 'Organization', 'name' => $en ? 'Farhoon editorial team' : 'فريق تحرير فرحون', 'url' => home_url('/team/')],
		'image' => ['@type' => 'ImageObject', 'url' => '%post_thumbnail%'],
	]);
	update_post_meta($id, 'farhoon_faq', wp_slash(wp_json_encode($d['faq'] ?? [], JSON_UNESCAPED_UNICODE)));
	update_post_meta($id, 'farhoon_minutes', (string) (int) ($d['reading_minutes'] ?? 0));
	update_post_meta($id, 'farhoon_snippet_query', $d['featured_snippet']['target_query'] ?? '');
	update_post_meta($id, 'farhoon_cta_text', $d['cta_text'] ?? '');
	update_post_meta($id, 'farhoon_number', (string) $d['number']);
	farhoon_pair_by_number($id, $type, $d['number']);
	$state = get_post_status($id) === 'publish' ? 'منشورة' : 'مسودة';
	return ['ok' => !$errors, 'msg' => ($en ? 'EN ' : '') . $d['number'] . ' · ' . $d['title'] . " ($state)" . ($errors ? ' — صور ناقصة: ' . implode('، ', $errors) : ''), 'edit' => get_edit_post_link($id, 'raw'), 'view' => get_permalink($id) ?: get_preview_post_link($id)];
}

add_action('wp_ajax_farhoon_import', function () {
	check_ajax_referer('farhoon_import');
	if (!current_user_can('manage_options')) wp_send_json_error('no');
	@set_time_limit(120);
	$file = (string) wp_unslash($_POST['file'] ?? '');
	if (!preg_match('/^[a-z0-9-]+(\.en)?\.json$/', $file)) wp_send_json_error('bad file');
	$status = ($_POST['status'] ?? '') === 'publish' ? 'publish' : 'draft';
	wp_send_json_success(farhoon_import_one($file, $status));
});

add_action('admin_menu', function () {
	add_management_page('مقالات فرحون', 'مقالات فرحون', 'manage_options', 'farhoon-import', function () {
		$index = farhoon_fetch_json('wp/articles-new/index.json');
		echo '<div class="wrap"><h1>استيراد مقالات فرحون</h1>';
		if (!$index) { echo '<p>تعذّر تنزيل قائمة المقالات من GitHub.</p></div>'; return; }
		echo '<p>المصدر: <code>' . esc_html(FARHOON_SRC . 'wp/articles-new/') . '</code>. المقالات الموجودة تُحدَّث ولا تتكرر، والصور تُرفع مرة واحدة.</p>';
		echo '<p><label><input type="radio" name="fst" value="draft" checked> مسودات (للمراجعة)</label> &nbsp; <label><input type="radio" name="fst" value="publish"> نشر مباشر</label></p>';
		echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th style="width:30px"><input type="checkbox" id="fall" checked></th><th>المقالة</th><th>النتيجة</th></tr></thead><tbody>';
		foreach ($index as $it) {
			echo '<tr><td><input type="checkbox" class="fone" value="' . esc_attr($it['file']) . '" checked></td><td>' . esc_html($it['number'] . ' · ' . $it['title']) . '</td><td class="fres"></td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary" id="fgo">استيراد المحدد</button> <span id="fsum"></span></p></div>';
		$nonce = wp_create_nonce('farhoon_import');
		?>
		<script>
		document.getElementById('fall').onchange = (e) => document.querySelectorAll('.fone').forEach((c) => c.checked = e.target.checked);
		document.getElementById('fgo').onclick = async (e) => {
			e.target.disabled = true;
			const status = document.querySelector('input[name=fst]:checked').value;
			const rows = [...document.querySelectorAll('.fone')].filter((c) => c.checked);
			let ok = 0;
			for (const c of rows) {
				const cell = c.closest('tr').querySelector('.fres');
				cell.textContent = '…';
				const body = new URLSearchParams({ action: 'farhoon_import', _ajax_nonce: '<?php echo esc_js($nonce); ?>', file: c.value, status });
				try {
					const r = await (await fetch(ajaxurl, { method: 'POST', body })).json();
					const d = r.data || {};
					cell.innerHTML = (d.ok ? '✅ ' : '⚠️ ') + (d.msg || 'خطأ') + (d.edit ? ' — <a href="' + d.edit + '">تحرير</a> · <a href="' + d.view + '" target="_blank">معاينة</a>' : '');
					if (d.ok) ok++;
				} catch (err) { cell.textContent = '⚠️ ' + err; }
			}
			document.getElementById('fsum').textContent = 'تم: ' + ok + ' من ' + rows.length;
			e.target.disabled = false;
		};
		</script>
		<?php
	});
});
