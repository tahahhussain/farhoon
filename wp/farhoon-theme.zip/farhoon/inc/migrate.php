<?php
/**
 * One-time site changes that come with a theme version. They run once, the first time an administrator
 * opens the dashboard after the theme is uploaded, and the result is shown as a notice.
 * Safe to run again: pages are matched by address and updated, never duplicated.
 */
defined('ABSPATH') || exit;

add_action('admin_init', function () {
	if (!current_user_can('manage_options')) return;
	$done = (string) get_option('farhoon_migrated');
	if (version_compare($done ?: '0', '1.1.0', '<')) {
		update_option('farhoon_migrate_log', farhoon_migrate_110(), false);
		update_option('farhoon_migrated', '1.1.0');
	}
	if (version_compare((string) get_option('farhoon_migrated'), '1.1.1', '<')) {
		update_option('farhoon_migrate_log', farhoon_migrate_111(), false);
		update_option('farhoon_migrated', '1.1.1');
	}
	if (version_compare((string) get_option('farhoon_migrated'), '1.3.0', '<')) {
		update_option('farhoon_migrate_log', farhoon_migrate_130(), false);
		update_option('farhoon_migrated', '1.3.0');
	}
	if (version_compare((string) get_option('farhoon_migrated'), '1.4.0', '<')) {
		update_option('farhoon_migrate_log', farhoon_migrate_140(), false);
		update_option('farhoon_migrated', '1.4.0');
	}
	if (version_compare((string) get_option('farhoon_migrated'), '1.5.0', '<')) {
		update_option('farhoon_migrate_log', farhoon_migrate_150(), false);
		update_option('farhoon_migrated', '1.5.0');
	}
});

/** 1.5.0: fixes from the SEO research (sitemap cache, one analytics tool, no right-click block, brand profiles) and the reviewers page. */
function farhoon_migrate_150() {
	$log = [];
	// Rank Math kept an old post sitemap (11 links) after 80 articles were published.
	if (class_exists('\RankMath\Sitemap\Cache')) { \RankMath\Sitemap\Cache::invalidate_storage(); $log[] = 'خرائط Rank Math أُعيد بناؤها.'; }
	global $wpdb;
	$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rank_math_sitemap%' OR option_name LIKE '_transient_timeout_rank_math_sitemap%'");
	// One analytics tool only (GA4 through Tag Manager): Burst Statistics is switched off, not deleted.
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	foreach (['burst-statistics/burst.php'] as $pl) {
		if (is_plugin_active($pl)) { deactivate_plugins($pl); $log[] = 'أُوقفت إضافة Burst Statistics (يبقى GA4 وحده). يمكن تفعيلها من الإضافات.'; }
	}
	// The right-click/drag blocker slows interaction and annoys readers.
	$aios = get_option('aio_wp_security_configs');
	if (is_array($aios) && !empty($aios['aiowps_copy_protection'])) { $aios['aiowps_copy_protection'] = ''; update_option('aio_wp_security_configs', $aios); $log[] = 'أُلغي منع النقر الأيمن (AIOS).'; }
	// Brand profiles for the Organization schema (sameAs).
	$titles = get_option('rank-math-options-titles', []);
	$profiles = array_filter(array_map('trim', explode("\n", (string) ($titles['social_additional_profiles'] ?? ''))));
	foreach (['https://www.youtube.com/@FarhoonApps'] as $u) if (!in_array($u, $profiles, true)) $profiles[] = $u;
	$titles['social_additional_profiles'] = implode("\n", $profiles);
	$titles['knowledgegraph_type'] = 'company';
	$titles['knowledgegraph_name'] = 'فرحون';
	$titles['website_alternate_name'] = 'Farhoon';
	update_option('rank-math-options-titles', $titles);
	$log[] = 'روابط العلامة (sameAs): قناة YouTube.';
	// Volunteer reviewers page, and the privacy page without Burst.
	$dir = get_stylesheet_directory() . '/content/pages/';
	foreach ([['join-reviewers', 'انضم إلى المراجعين الشرعيين المتطوعين', 'مراجعون شرعيون متطوعون | فرحون', 'يبحث فرحون عن طلبة علم ومشايخ متطوعين يراجعون مقالات الصلاة والقرآن والأذكار والزكاة ومحتوى تطبيق رفيق الطاعة، ويظهر اسم المراجع مع تاريخ المراجعة.'], ['privacy', null, null, null]] as [$slug, $title, $seo, $desc]) {
		$p = get_page_by_path($slug);
		$html = file_get_contents($dir . $slug . '.html');
		if ($p) { wp_update_post(wp_slash(['ID' => $p->ID, 'post_content' => $html])); $id = $p->ID; }
		elseif ($title) { $id = wp_insert_post(wp_slash(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $html, 'comment_status' => 'closed'])); }
		if (!empty($id) && $seo) { update_post_meta($id, 'rank_math_title', $seo); update_post_meta($id, 'rank_math_description', $desc); $log[] = 'صفحة /join-reviewers/ جاهزة.'; }
	}
	flush_rewrite_rules(false);
	if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
	$log[] = 'امسح ذاكرة NGINX المؤقتة من cPanel.';
	return $log;
}

/** 1.4.0: prayer-time pages for 42 cities and the Ramadan 1448 imsakiya (inc/prayer-pages.php). */
function farhoon_migrate_140() {
	flush_rewrite_rules(false);
	if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
	return ['صفحات مواقيت الصلاة جاهزة: /prayer-times/ و/ramadan-imsakiya/ وخريطتها /prayer-times.xml.', 'مستورد المقالات صار يستورد المقالات الإنجليزية ويربطها بالعربية.', 'امسح ذاكرة NGINX المؤقتة من cPanel.'];
}

/** 1.3.0: the site privacy policy now names Google Analytics (through Tag Manager). */
function farhoon_migrate_130() {
	$p = get_page_by_path('privacy');
	$file = get_stylesheet_directory() . '/content/pages/privacy.html';
	if ($p && file_exists($file) && get_post_meta($p->ID, '_elementor_edit_mode', true) !== 'builder') {
		wp_update_post(wp_slash(['ID' => $p->ID, 'post_content' => file_get_contents($file)]));
	}
	if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
	return ['سياسة الخصوصية تحدّثت (Google Analytics عبر Tag Manager).', 'ضع معرّف Tag Manager في الإعدادات ← فرحون ليبدأ التتبع، ثم امسح ذاكرة NGINX.'];
}

/** 1.1.1: Rank Math stops writing its whole schema graph on pages when their schema type is "off",
 * so pages keep the Article type in Rank Math and the theme drops that one node instead (inc/seo.php). */
function farhoon_migrate_111() {
	$titles = get_option('rank-math-options-titles', []);
	$titles['pt_page_default_rich_snippet'] = 'article';
	update_option('rank-math-options-titles', $titles);
	if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
	return ['Rank Math: عاد مخطط WebSite وWebPage للصفحات (ونوع Article يُحذف من القالب).', 'امسح ذاكرة NGINX المؤقتة من cPanel.'];
}

add_action('admin_notices', function () {
	$log = get_option('farhoon_migrate_log');
	if (!$log || !current_user_can('manage_options')) return;
	echo '<div class="notice notice-info is-dismissible"><p><strong>تحديث قالب فرحون:</strong></p><ul style="list-style:disc;padding-inline-start:20px">';
	foreach ($log as $line) echo '<li>' . esc_html($line) . '</li>';
	echo '</ul></div>';
	delete_option('farhoon_migrate_log');
});

function farhoon_migrate_110() {
	$log = [];

	// Rank Math: plain pages are WebPage (no Article schema), no author archives, images in the sitemap.
	$titles = get_option('rank-math-options-titles', []);
	$titles['disable_author_archives'] = 'on';
	update_option('rank-math-options-titles', $titles);
	$sitemap = get_option('rank-math-options-sitemap', []);
	$sitemap['include_images'] = 'on';
	$sitemap['include_featured_image'] = 'on';
	update_option('rank-math-options-sitemap', $sitemap);
	foreach (get_posts(['post_type' => 'page', 'numberposts' => -1, 'post_status' => 'any']) as $p) {
		delete_post_meta($p->ID, 'rank_math_rich_snippet');
		foreach (array_keys(get_post_meta($p->ID)) as $k) if (strpos($k, 'rank_math_schema_') === 0) delete_post_meta($p->ID, $k);
	}
	$log[] = 'Rank Math: الصفحات بلا نوع Article، والصور في خريطة الموقع، وأرشيف الكاتب مغلق.';

	// The public author name is the editorial team, not the login name.
	foreach (get_users(['role' => 'administrator']) as $u) {
		if (in_array($u->display_name, ['admin', $u->user_login], true)) {
			wp_update_user(['ID' => $u->ID, 'display_name' => 'فريق تحرير فرحون', 'nickname' => 'فريق تحرير فرحون', 'description' => 'فريق فرحون الذي يكتب مقالات المدونة ويراجعها على مصادرها.']);
			$log[] = 'اسم الكاتب الظاهر صار «فريق تحرير فرحون» (اسم الدخول لم يتغير).';
		}
	}

	// Alternative text for images that have none (screenshots, logos, kids games).
	$alts = [
		'logo-dark' => 'شعار فرحون', 'mark' => 'علامة فرحون', 'face-circle' => 'وجه فرحون المبتسم', 'rafiq-icon' => 'أيقونة تطبيق رفيق الطاعة',
		's01-home' => 'الشاشة الرئيسية لتطبيق رفيق الطاعة مع الصلاة القادمة', 's02-mushaf' => 'مصحف المدينة في رفيق الطاعة',
		's03-tajweed' => 'دروس التجويد في رفيق الطاعة', 's04-prayer' => 'مواقيت الصلاة في رفيق الطاعة', 's05-qibla' => 'بوصلة اتجاه القبلة في رفيق الطاعة',
		's06-radio' => 'إذاعة القرآن الكريم في رفيق الطاعة', 's07-adhkar' => 'أذكار الصباح والمساء بعدّاد في رفيق الطاعة', 's08-hisn' => 'حصن المسلم في رفيق الطاعة',
		's09-tasbih' => 'السبحة الإلكترونية في رفيق الطاعة', 's10-qudsi' => 'الأحاديث القدسية في رفيق الطاعة', 's11-stories' => 'قصص الأنبياء والصحابة في رفيق الطاعة',
		's12-fiqh' => 'الفقه المبسط في رفيق الطاعة', 's13-fatawa' => 'الفتاوى في رفيق الطاعة', 's14-zakat' => 'حاسبة الزكاة في رفيق الطاعة',
		's15-taat' => 'قائمة طاعاتي اليومية في رفيق الطاعة', 's16-calendar' => 'التقويم الهجري والمناسبات في رفيق الطاعة', 's17-imsakiya' => 'إمساكية رمضان في رفيق الطاعة',
		's18-quiz' => 'المسابقة الإسلامية في رفيق الطاعة', 's19-games' => 'ألعاب الأطفال في رفيق الطاعة', 's20-debates' => 'مناظرات القرآن في رفيق الطاعة', 's21-ilm' => 'موسوعة العلماء في رفيق الطاعة',
		'alphabet-learning' => 'لعبة تعلّم الحروف للأطفال من فرحون', 'coloring-studio' => 'لعبة التلوين للأطفال من فرحون', 'jigsaw-adventure' => 'لعبة تركيب الصور للأطفال من فرحون',
		'dinosaur-adventure' => 'لعبة مغامرة الديناصور للأطفال من فرحون', 'kids-cartoon-racing' => 'لعبة السباق الكرتونية للأطفال من فرحون',
	];
	$n = 0;
	foreach (get_posts(['post_type' => 'attachment', 'numberposts' => -1, 'post_status' => 'inherit', 'post_mime_type' => 'image', 'fields' => 'ids']) as $id) {
		if (trim((string) get_post_meta($id, '_wp_attachment_image_alt', true)) !== '') continue;
		$base = preg_replace('/(-\d+)?(-\d+x\d+)?\.(png|webp|jpe?g|svg)$/i', '', basename((string) get_attached_file($id)));
		if (isset($alts[$base])) { update_post_meta($id, '_wp_attachment_image_alt', $alts[$base]); $n++; }
	}
	$log[] = "نص بديل لـ $n صورة.";

	// The Rafiq pages: "coming soon to Google Play and App Store" becomes the store switch.
	$swap = [
		'<span class="f-soon">قريبًا على Google Play وApp Store</span>' => '[farhoon_play spot="rafiq-page"]',
		'<span class="f-soon">Coming soon to Google Play and the App Store</span>' => '[farhoon_play spot="rafiq-page"]',
	];
	foreach (['rafiq', 'en/rafiq'] as $path) {
		$p = get_page_by_path($path);
		if (!$p) continue;
		$raw = get_post_meta($p->ID, '_elementor_data', true);
		$data = is_string($raw) ? json_decode($raw, true) : $raw;
		if (is_array($data)) {
			$changed = false;
			array_walk_recursive($data, function (&$v) use ($swap, &$changed) {
				if (is_string($v) && strpos($v, 'f-soon') !== false) { $nv = strtr($v, $swap); if ($nv !== $v) { $v = $nv; $changed = true; } }
			});
			if ($changed) { update_post_meta($p->ID, '_elementor_data', wp_slash(wp_json_encode($data))); $log[] = "صفحة $path: زر المتجر جاهز (يظهر عند تفعيل الخيار)."; }
			else $log[] = "صفحة $path: لم يُعثر على نص «قريبًا».";
		}
		$content = strtr($p->post_content, $swap);
		if ($content !== $p->post_content) wp_update_post(wp_slash(['ID' => $p->ID, 'post_content' => $content]));
	}
	if (class_exists('\Elementor\Plugin')) \Elementor\Plugin::$instance->files_manager->clear_cache();

	// New pages: support, terms, privacy, editorial policy, team, press.
	$dir = get_stylesheet_directory() . '/content/pages/';
	$rafiq = get_page_by_path('rafiq');
	$pages = [
		['rafiq/support', 'support', 'دعم رفيق الطاعة والأسئلة الشائعة', 'دعم رفيق الطاعة | حلول الأذان والمواقيت والقبلة', 'حلول أشهر مشكلات رفيق الطاعة: الأذان لا يعمل والتطبيق مغلق، واختلاف المواقيت، ومعايرة القبلة، وما يعمل بدون إنترنت، وطريقة التواصل معنا.'],
		['rafiq/terms', 'rafiq-terms', 'شروط استخدام رفيق الطاعة', 'شروط استخدام رفيق الطاعة | فرحون', 'شروط استخدام تطبيق رفيق الطاعة المجاني بلا إعلانات: المحتوى الشرعي، ودقة المواقيت والقبلة والزكاة، والاستخدام المقبول، وحدود المسؤولية.'],
		['privacy', 'privacy', 'سياسة خصوصية الموقع', 'سياسة خصوصية موقع فرحون', 'ما يجمعه موقع فرحون ولماذا: رسائل التواصل والتعليقات وإحصاءات مجهولة على خادمنا، بلا إعلانات ولا بيع بيانات. وحقك في طلب حذف بياناتك.'],
		['terms', 'terms', 'شروط استخدام الموقع', 'شروط استخدام موقع فرحون', 'شروط استخدام موقع فرحون: طبيعة المحتوى الشرعي، والاقتباس مع ذكر المصدر، والتعليقات، والروابط الخارجية، والعلامة التجارية.'],
		['editorial-policy', 'editorial-policy', 'منهجنا في المحتوى', 'منهجنا في المحتوى الشرعي | فرحون', 'كيف نكتب مقالات فرحون: الآيات بنص مصحف المدينة، والأحاديث بمصادرها ودرجتها، وقول الجمهور في الأحكام، ومراجعة بشرية قبل النشر، وتصحيح الأخطاء.'],
		['team', 'team', 'فريق تحرير فرحون', 'فريق تحرير فرحون | من يكتب المقالات', 'تعرّف على فريق تحرير فرحون الذي يكتب مقالات الصلاة والقرآن والأذكار والزكاة وتربية الأطفال، ويراجعها على مصادرها قبل النشر.'],
		['press', 'press', 'الملف الصحفي', 'الملف الصحفي لفرحون ورفيق الطاعة', 'الملف الصحفي لفرحون: نبذة عن الاستوديو وتطبيق رفيق الطاعة، والشعار والأيقونات والصور، والاسم الصحيح، وطريقة التواصل مع الفريق.'],
	];
	foreach ($pages as [$path, $file, $title, $seo_title, $desc]) {
		if (!file_exists($dir . $file . '.html')) { $log[] = "ملف ناقص: $file"; continue; }
		$slug = basename($path);
		$parent = strpos($path, 'rafiq/') === 0 && $rafiq ? $rafiq->ID : 0;
		$existing = get_page_by_path($path);
		$post = ['post_type' => 'page', 'post_title' => $title, 'post_name' => $slug, 'post_parent' => $parent, 'post_status' => 'publish', 'post_content' => file_get_contents($dir . $file . '.html'), 'comment_status' => 'closed'];
		if ($existing) {
			// A page someone built in Elementor is left alone.
			if (get_post_meta($existing->ID, '_elementor_edit_mode', true) === 'builder') { $log[] = "تُرك كما هو (Elementor): /$path/"; continue; }
			$post['ID'] = $existing->ID;
		}
		$id = $existing ? wp_update_post(wp_slash($post), true) : wp_insert_post(wp_slash($post), true);
		if (is_wp_error($id)) { $log[] = "فشل /$path/: " . $id->get_error_message(); continue; }
		update_post_meta($id, 'rank_math_title', $seo_title);
		update_post_meta($id, 'rank_math_description', $desc);
		$log[] = ($existing ? 'تحدّثت' : 'أُنشئت') . " /$path/";
	}
	// WordPress's own sample privacy page is not used.
	$wp_privacy = (int) get_option('wp_page_for_privacy_policy');
	$ours = get_page_by_path('privacy');
	if ($ours) update_option('wp_page_for_privacy_policy', $ours->ID);
	if ($wp_privacy && $ours && $wp_privacy !== $ours->ID && get_post_status($wp_privacy) === 'draft') wp_trash_post($wp_privacy);

	flush_rewrite_rules(false);
	if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
	$log[] = 'امسح ذاكرة NGINX المؤقتة من cPanel لتظهر التغييرات للزوار فورًا.';
	return $log;
}
