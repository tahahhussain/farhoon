<?php
/**
 * Tools → نسخة إعدادات فرحون: one JSON file with the site's pages, Elementor designs, menus, categories,
 * theme and plugin settings and the plugin list, for the private settings repository on GitHub.
 * It never contains people's data: no users, comments, contact messages or e-mail addresses, and any
 * setting whose name looks like a key, token, password, licence or address is left out.
 * Article text is not included because the articles' source files already live in the public repository.
 */
defined('ABSPATH') || exit;

/** True for setting names that may hold secrets or personal data. */
function farhoon_export_secret($name) {
	return (bool) preg_match('/key|token|secret|passw|licen[cs]e|auth|salt|nonce|e-?mail|(^|_)api|cookie|session|(^|_)ips?(_|$)|login|user|connect|credential|smtp|hash/i', (string) $name);
}

/** Removes secret-looking keys at any depth. */
function farhoon_export_clean($v) {
	if (is_object($v)) $v = (array) $v;
	if (!is_array($v)) return $v;
	$out = [];
	foreach ($v as $k => $x) {
		if (is_string($k) && farhoon_export_secret($k)) continue;
		$out[$k] = farhoon_export_clean($x);
	}
	return $out;
}

/** Settings worth keeping, by name prefix. Security, backup and mail plugins are left out on purpose. */
function farhoon_export_options() {
	global $wpdb;
	$keep = ['farhoon_', 'rank-math-options', 'rank_math_modules', 'elementor_', 'autoptimize', 'theme_mods_', 'sidebars_widgets', 'widget_', 'wpseo'];
	$core = ['blogname', 'blogdescription', 'permalink_structure', 'category_base', 'tag_base', 'timezone_string', 'gmt_offset', 'date_format', 'time_format', 'WPLANG', 'show_on_front', 'page_on_front', 'page_for_posts', 'posts_per_page', 'blog_public', 'default_comment_status', 'comment_moderation', 'thumbnail_size_w', 'thumbnail_size_h', 'medium_size_w', 'medium_size_h', 'large_size_w', 'large_size_h', 'template', 'stylesheet', 'nav_menu_options', 'site_icon'];
	$rows = $wpdb->get_results("SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name NOT LIKE '\\_%' ORDER BY option_name");
	$out = [];
	foreach ($rows as $r) {
		$n = $r->option_name;
		$ok = in_array($n, $core, true);
		foreach ($keep as $p) if (strpos($n, $p) === 0) $ok = true;
		if (!$ok || farhoon_export_secret($n) || strpos($n, 'elementor_log') === 0 || strpos($n, '_transient') !== false) continue;
		$out[$n] = farhoon_export_clean(maybe_unserialize($r->option_value));
	}
	return $out;
}

/** Pages and Elementor templates with their designs and SEO fields. */
function farhoon_export_pages() {
	$out = [];
	$items = get_posts(['post_type' => ['page', 'elementor_library'], 'post_status' => ['publish', 'draft', 'private', 'future'], 'numberposts' => -1, 'orderby' => 'ID', 'order' => 'ASC']);
	foreach ($items as $p) {
		$meta = [];
		foreach (get_post_meta($p->ID) as $k => $v) {
			if (preg_match('/^(_elementor_(data|page_settings|template_type|edit_mode|conditions)|_wp_page_template|rank_math_(?!internal|analytic).+|farhoon_.+)$/', $k) && !farhoon_export_secret($k)) {
				$val = maybe_unserialize($v[0]);
				if ($k === '_elementor_data' && is_string($val)) $val = json_decode($val, true) ?? $val;
				$meta[$k] = farhoon_export_clean($val);
			}
		}
		$out[] = ['id' => $p->ID, 'type' => $p->post_type, 'slug' => $p->post_name, 'path' => $p->post_type === 'page' ? get_page_uri($p) : '', 'title' => $p->post_title, 'status' => $p->post_status, 'parent' => $p->post_parent, 'menu_order' => $p->menu_order, 'modified_gmt' => $p->post_modified_gmt, 'content' => $p->post_content, 'meta' => $meta];
	}
	return $out;
}

/** Article list (address, state, date, number); the text itself is in the public article files. */
function farhoon_export_articles() {
	$out = [];
	foreach (get_posts(['post_type' => ['post', 'en_post'], 'post_status' => ['publish', 'future', 'draft'], 'numberposts' => -1, 'orderby' => 'ID', 'order' => 'ASC']) as $p) {
		$thumb = get_post_thumbnail_id($p->ID);
		$out[] = ['id' => $p->ID, 'type' => $p->post_type, 'number' => get_post_meta($p->ID, 'farhoon_number', true), 'slug' => $p->post_name, 'status' => $p->post_status, 'date_gmt' => $p->post_date_gmt, 'modified_gmt' => $p->post_modified_gmt, 'title' => $p->post_title, 'url' => get_permalink($p), 'pair' => get_post_meta($p->ID, 'farhoon_pair', true), 'reviewer' => get_post_meta($p->ID, 'farhoon_reviewer', true), 'image' => $thumb ? get_post_meta($thumb, 'farhoon_source', true) : ''];
	}
	return $out;
}

function farhoon_export_menus() {
	$out = ['locations' => get_nav_menu_locations(), 'menus' => []];
	foreach (wp_get_nav_menus() as $m) {
		$items = [];
		foreach (wp_get_nav_menu_items($m->term_id) ?: [] as $i) {
			$items[] = ['id' => $i->ID, 'parent' => (int) $i->menu_item_parent, 'order' => $i->menu_order, 'title' => $i->title, 'url' => $i->url, 'type' => $i->type, 'object' => $i->object, 'object_id' => (int) $i->object_id, 'classes' => array_values(array_filter((array) $i->classes))];
		}
		$out['menus'][] = ['id' => $m->term_id, 'name' => $m->name, 'slug' => $m->slug, 'items' => $items];
	}
	return $out;
}

function farhoon_export_terms() {
	$out = [];
	foreach (['category', 'post_tag', 'en_category'] as $tax) {
		if (!taxonomy_exists($tax)) continue;
		foreach (get_terms(['taxonomy' => $tax, 'hide_empty' => false]) as $t) {
			$out[$tax][] = ['id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug, 'parent' => $t->parent, 'description' => $t->description, 'count' => $t->count];
		}
	}
	return $out;
}

function farhoon_export_plugins() {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	$active = (array) get_option('active_plugins', []);
	$out = [];
	foreach (get_plugins() as $file => $p) $out[] = ['file' => $file, 'name' => $p['Name'], 'version' => $p['Version'], 'active' => in_array($file, $active, true)];
	return $out;
}

function farhoon_export_all() {
	$theme = wp_get_theme();
	return [
		'generated_gmt' => gmdate('c'),
		'site' => home_url('/'),
		'wordpress' => get_bloginfo('version'),
		'php' => PHP_VERSION,
		'theme' => ['name' => $theme->get('Name'), 'version' => $theme->get('Version'), 'parent' => $theme->parent() ? $theme->parent()->get('Name') . ' ' . $theme->parent()->get('Version') : '', 'custom_css' => wp_get_custom_css()],
		'plugins' => farhoon_export_plugins(),
		'options' => farhoon_export_options(),
		'menus' => farhoon_export_menus(),
		'terms' => farhoon_export_terms(),
		'pages' => farhoon_export_pages(),
		'articles' => farhoon_export_articles(),
	];
}

add_action('wp_ajax_farhoon_export', function () {
	check_ajax_referer('farhoon_export');
	if (!current_user_can('manage_options')) wp_send_json_error('no');
	wp_send_json_success(farhoon_export_all());
});

add_action('admin_menu', function () {
	add_management_page('نسخة إعدادات فرحون', 'نسخة إعدادات فرحون', 'manage_options', 'farhoon-export', function () {
		$nonce = wp_create_nonce('farhoon_export');
		echo '<div class="wrap"><h1>نسخة إعدادات فرحون</h1><p>ملف JSON فيه الصفحات وتصميمات Elementor والقوائم والتصنيفات وإعدادات القالب والإضافات وقائمة المقالات. لا يحتوي على المستخدمين أو التعليقات أو رسائل التواصل أو أي مفتاح أو كلمة مرور.</p>';
		echo '<p><button class="button button-primary" id="fexp" data-nonce="' . esc_attr($nonce) . '">تنزيل النسخة</button> <span id="fexps"></span></p></div>';
		?>
		<script>
		document.getElementById('fexp').onclick = async (e) => {
			const s = document.getElementById('fexps'); s.textContent = '…';
			const body = new URLSearchParams({ action: 'farhoon_export', _ajax_nonce: e.target.dataset.nonce });
			const r = await (await fetch(ajaxurl, { method: 'POST', body })).json();
			if (!r.success) { s.textContent = 'خطأ'; return; }
			const blob = new Blob([JSON.stringify(r.data, null, 1)], { type: 'application/json' });
			const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
			a.download = 'farhoon-site-export-' + new Date().toISOString().slice(0, 10) + '.json'; a.click();
			s.textContent = Math.round(blob.size / 1024) + ' KB';
		};
		</script>
		<?php
	});
});
