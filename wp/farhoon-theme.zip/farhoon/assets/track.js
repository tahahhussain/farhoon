// Farhoon measurement events for Google Tag Manager (dataLayer). Loaded on every page, Elementor pages too.
// Events: store_click (any Google Play link), cta_click, cta_impression, share, contact_email, contact_submit (from contact.js).
(() => {
	const dl = (window.dataLayer = window.dataLayer || []);
	const page = location.pathname;
	const kind = document.body.classList.contains('single-post') || document.body.classList.contains('single-en_post') ? 'article' : 'page';
	document.addEventListener('click', (e) => {
		const a = e.target.closest('a, button');
		if (!a) return;
		const href = a.getAttribute('href') || '';
		const cta = a.dataset.cta || (a.closest('.f-cta') ? 'article-box' : a.closest('.f-endcta') ? 'article-end' : a.closest('.f-bar') ? 'phone-bar' : '');
		if (/play\.google\.com/.test(href) || /\/get\/rafiq\/?/.test(href)) {
			dl.push({ event: 'store_click', store: 'google_play', cta_position: cta || 'link', page_type: kind, link_url: href });
		} else if (cta) {
			dl.push({ event: 'cta_click', cta_position: cta, page_type: kind, link_url: href });
		}
		if (a.classList.contains('f-sh')) dl.push({ event: 'share', method: (a.className.match(/f-sh-(\w+)/) || [])[1] || 'other', page_type: kind });
		if (href.startsWith('mailto:')) dl.push({ event: 'contact_email', page_type: kind });
	});
	if ('IntersectionObserver' in window) {
		const seen = new IntersectionObserver((entries) => entries.forEach((en) => {
			if (!en.isIntersecting) return;
			const el = en.target;
			dl.push({ event: 'cta_impression', cta_position: el.classList.contains('f-endcta') ? 'article-end' : el.classList.contains('f-bar') ? 'phone-bar' : 'article-box', page_type: kind });
			seen.unobserve(el);
		}), { threshold: 0.5 });
		document.querySelectorAll('.f-cta, .f-endcta').forEach((el) => seen.observe(el));
	}
})();
