// Farhoon theme: more articles while scrolling, copy link, back to top.
(() => {
	const grid = document.querySelector('[data-infinite]');
	const more = document.querySelector('.f-more');
	if (grid && more && 'IntersectionObserver' in window) {
		let busy = false;
		const io = new IntersectionObserver(async (entries) => {
			const link = more.querySelector('.f-next');
			if (!entries[0].isIntersecting || busy || !link) return;
			busy = true;
			link.classList.add('is-loading');
			try {
				const page = new DOMParser().parseFromString(await (await fetch(link.href)).text(), 'text/html');
				page.querySelectorAll('[data-infinite] > .f-card').forEach((card) => grid.appendChild(card));
				const next = page.querySelector('.f-more .f-next');
				if (next) link.href = next.href; else { io.disconnect(); more.remove(); }
			} catch (e) {
				// The link still works as a normal next page.
			} finally {
				busy = false;
				link.classList.remove('is-loading');
			}
		}, { rootMargin: '700px 0px' });
		io.observe(more);
	}
	document.querySelectorAll('[data-copy]').forEach((btn) => btn.addEventListener('click', () => {
		if (!navigator.clipboard) return;
		navigator.clipboard.writeText(location.href).then(() => {
			btn.classList.add('ok');
			setTimeout(() => btn.classList.remove('ok'), 1600);
		});
	}));
	const top = document.querySelector('.f-top');
	if (top) {
		addEventListener('scroll', () => top.classList.toggle('show', scrollY > 700), { passive: true });
		top.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));
	}
})();
