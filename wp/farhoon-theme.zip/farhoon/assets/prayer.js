// City prayer pages: show the right day even when the page came from the cache, mark this month's row,
// and say which prayer is next and how long until it, in the city's own time zone.
(function () {
	var el = document.getElementById('pt-data');
	if (!el) return;
	var data = JSON.parse(el.textContent);
	if (!data.days || !data.days.length) return;
	var maghreb = /^(MA|DZ|TN)$/.test(data.cc);
	var digits = function (s) {
		return maghreb ? String(s) : String(s).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'[d]; });
	};
	function nowIn(tz) {
		var p = {};
		new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })
			.formatToParts(new Date()).forEach(function (x) { p[x.type] = x.value; });
		return { date: p.year + '-' + p.month + '-' + p.day, sec: (+p.hour) * 3600 + (+p.minute) * 60 + (+p.second) };
	}
	var keys = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
	var toSec = function (hhmm) { var a = hhmm.split(':'); return a[0] * 3600 + a[1] * 60; };
	var shown = null;
	function tick() {
		var now = nowIn(data.tz);
		var i = data.days.findIndex(function (d) { return d.d === now.date; });
		if (i < 0) return;
		var day = data.days[i];
		if (shown !== day.d) {
			shown = day.d;
			keys.forEach(function (k, j) {
				var t = document.querySelector('.pt-card[data-k="' + k + '"] .pt-time');
				if (t) t.textContent = day.t[j];
			});
			var lab = document.getElementById('pt-date');
			if (lab) lab.textContent = day.label;
			document.querySelectorAll('.pt-table tr[data-date]').forEach(function (tr) {
				tr.classList.toggle('on', tr.getAttribute('data-date') === day.d);
			});
		}
		// Next prayer (sunrise is not a prayer, so it is skipped).
		var next = null;
		[0, 2, 3, 4, 5].some(function (j) { if (toSec(day.raw[j]) > now.sec) { next = { j: j, s: toSec(day.raw[j]) - now.sec }; return true; } return false; });
		if (!next && data.days[i + 1]) next = { j: 0, s: 86400 - now.sec + toSec(data.days[i + 1].raw[0]) };
		document.querySelectorAll('.pt-card').forEach(function (c) { c.classList.remove('next'); });
		var box = document.getElementById('pt-next');
		if (!next || !box) return;
		var card = document.querySelector('.pt-card[data-k="' + keys[next.j] + '"]');
		if (card && toSec(day.raw[next.j]) > now.sec) card.classList.add('next');
		var h = Math.floor(next.s / 3600), m = Math.floor((next.s % 3600) / 60), s = next.s % 60;
		var pad = function (n) { return (n < 10 ? '0' : '') + n; };
		box.textContent = 'الصلاة القادمة: ' + data.names[next.j] + ' بعد ' + digits(h + ':' + pad(m) + ':' + pad(s));
		box.hidden = false;
	}
	tick();
	setInterval(tick, 1000);
})();
