// Farhoon contact form: sends without reloading and shows the reply under the button.
(() => {
	document.querySelectorAll('[data-farhoon-contact]').forEach((form) => {
		const stamp = form.querySelector('[name="ts"]');
		stamp.value = Math.floor(Date.now() / 1000);
		const status = form.querySelector('.f-form-status');
		const button = form.querySelector('button[type="submit"]');
		form.addEventListener('submit', async (e) => {
			e.preventDefault();
			if (!form.reportValidity()) return;
			button.disabled = true;
			status.className = 'f-form-status';
			status.textContent = form.lang === 'en' ? 'Sending…' : 'جارٍ الإرسال…';
			try {
				const res = await fetch(form.action, { method: 'POST', body: new FormData(form) });
				const data = await res.json();
				status.textContent = data.message || '';
				status.classList.add(data.ok ? 'ok' : 'err');
				if (data.ok) form.reset();
			} catch (err) {
				status.textContent = form.lang === 'en' ? 'Could not send. Please email hello@farhoon.com.' : 'تعذّر الإرسال. راسلنا على hello@farhoon.com.';
				status.classList.add('err');
			} finally {
				button.disabled = false;
				stamp.value = Math.floor(Date.now() / 1000);
			}
		});
	});
})();
