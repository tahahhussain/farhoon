<?php
// Prayer-time pages (inc/prayer-pages.php): the two hubs, a country, or a city with its Ramadan imsakiya.
defined('ABSPATH') || exit;
$ctx = farhoon_pt_ctx();
$seo = farhoon_pt_seo();
$countries = farhoon_pt_countries();
$names = farhoon_pt_names();
$keys = array_keys($names);
get_header();
?>
<main id="main" class="f-main pt">
<?php
/* ======================= city ======================= */
if ($ctx['kind'] === 'city') :
	$d = $ctx['data'];
	$c = $countries[$d['country']];
	$cc = $d['cc'];
	[$today, $ti, $row] = farhoon_pt_today($d);
	$method = farhoon_pt_method($d['method']);
	$hijri_note = $cc === 'SA' ? 'بحسب تقويم أم القرى' : 'بحسب تقويم أم القرى، وقد يختلف يومًا عن التقويم المحلي لأن بداية الشهر تتبع رؤية الهلال';
	?>
	<section class="f-band">
		<div class="f-wrap">
			<h1><?php echo esc_html($d['phrase'] . ' في ' . $d['name'] . ' اليوم'); ?></h1>
			<p class="f-band-sub" id="pt-date"><?php
				echo $row ? esc_html(farhoon_pt_gdate($today, $d['country'], true, true) . ' · ' . farhoon_pt_hdate($row[7], $cc)) : '';
			?></p>
			<?php $crumbs = farhoon_pt_crumbs([['مواقيت الصلاة', farhoon_pt_url()], [$c['name'], farhoon_pt_url($d['country'])], [$d['name'], '']]); ?>
		</div>
	</section>
	<div class="f-wrap pt-body">
		<?php if ($row) : ?>
			<section class="pt-today" aria-labelledby="pt-today-h">
				<h2 id="pt-today-h">أوقات الأذان اليوم في <?php echo esc_html($d['name']); ?></h2>
				<ol class="pt-cards">
					<?php foreach ($keys as $k => $key) : ?>
						<li class="pt-card pt-<?php echo esc_attr($key); ?>" data-k="<?php echo esc_attr($key); ?>">
							<span class="pt-name"><?php echo esc_html($names[$key]); ?></span>
							<time class="pt-time"><?php echo esc_html(farhoon_pt_time($row[$k + 1], $cc)); ?></time>
						</li>
					<?php endforeach; ?>
				</ol>
				<p class="pt-next" id="pt-next" hidden></p>
				<p class="pt-small">التاريخ الهجري <?php echo esc_html($hijri_note); ?>. الأوقات بالتوقيت المحلي لمدينة <?php echo esc_html($d['name']); ?>.</p>
			</section>
		<?php else : ?>
			<p class="pt-note">انتهت مدة جدول هذه الصفحة، ونعمل على تحديثه. يمكنك الرجوع إلى التقويم الرسمي: <a href="<?php echo esc_url($c['url']); ?>" rel="noopener" target="_blank"><?php echo esc_html($c['auth']); ?></a>.</p>
		<?php endif; ?>

		<section class="pt-facts" aria-label="معلومات المدينة">
			<div><strong>اتجاه القبلة</strong><span><?php
				echo $d['makkah_km'] < 5
					? 'أنت في مكة المكرمة: القبلة هي الكعبة المشرفة نفسها'
					: esc_html(farhoon_pt_n(number_format($d['qibla'], 1), $cc) . '° من الشمال الجغرافي باتجاه عقارب الساعة (جهة ' . farhoon_pt_direction($d['qibla']) . ')');
			?></span></div>
			<div><strong>المسافة إلى مكة المكرمة</strong><span><?php echo esc_html(farhoon_pt_n(number_format($d['makkah_km']), $cc) . ' كم تقريبًا (بخط مستقيم على سطح الأرض)'); ?></span></div>
			<div><strong>طريقة الحساب</strong><span><?php echo esc_html('طريقة ' . $method[0]); ?></span></div>
			<?php if ($row) : ?>
				<div><strong>طول النهار اليوم</strong><span><?php echo esc_html(farhoon_pt_duration(farhoon_pt_minutes($row[2], $row[5]), $cc) . ' من الشروق إلى المغرب'); ?></span></div>
			<?php endif; ?>
		</section>

		<?php
		// This month's table.
		$month = substr($row ? $today : $d['first'], 0, 7);
		$rows = array_values(array_filter($d['days'], fn($r) => substr($r[0], 0, 7) === $month));
		[$my, $mm] = array_map('intval', explode('-', $month));
		$mname = farhoon_pt_months($c['months'])[$mm - 1] . ' ' . farhoon_pt_n($my, $cc);
		?>
		<section class="pt-sec" id="month">
			<h2><?php echo esc_html($d['phrase'] . ' في ' . $d['name'] . ' لشهر ' . $mname); ?></h2>
			<div class="pt-scroll"><table class="pt-table">
				<thead><tr><th>اليوم</th><th>الهجري</th><?php foreach ($names as $n) echo '<th>' . esc_html($n) . '</th>'; ?></tr></thead>
				<tbody>
				<?php foreach ($rows as $r) : ?>
					<tr data-date="<?php echo esc_attr($r[0]); ?>"<?php echo $r[0] === $today ? ' class="on"' : ''; ?>>
						<th scope="row"><?php echo esc_html(farhoon_pt_gdate($r[0], $d['country'], false, true)); ?></th>
						<td><?php echo esc_html(farhoon_pt_hdate($r[7], $cc, false)); ?></td>
						<?php for ($k = 1; $k <= 6; $k++) echo '<td>' . esc_html(farhoon_pt_time($r[$k], $cc)) . '</td>'; ?>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		</section>

		<?php farhoon_pt_imsakiya($d); ?>

		<section class="pt-sec" id="method">
			<h2>طريقة الحساب والجهة الرسمية <?php echo esc_html($c['in']); ?></h2>
			<p>حسبنا <?php echo esc_html($d['phrase']); ?> في <?php echo esc_html($d['name']); ?> بطريقة <strong><?php echo esc_html($method[0]); ?></strong>: <?php echo esc_html($method[1]); ?>. ووقت العصر على قول الجمهور (حين يصير ظل الشيء مثله)، وهي الإعدادات نفسها التي يستعملها تطبيق رفيق الطاعة لمدن <?php echo esc_html($c['name']); ?>.</p>
			<p>هذه أقرب طريقة حسابية متاحة لتقويم الجهة الرسمية، والمرجع المعتمد هو تقويم <a href="<?php echo esc_url($c['url']); ?>" rel="noopener" target="_blank"><?php echo esc_html($c['auth']); ?></a>. إحداثيات النقطة المحسوبة: <?php echo esc_html(farhoon_pt_n($d['lat'], $cc) . '، ' . farhoon_pt_n($d['lng'], $cc)); ?>.</p>
		</section>

		<?php farhoon_pt_why($d); ?>

		<section class="pt-sec">
			<h2>مدن قريبة</h2>
			<ul class="pt-near">
				<?php foreach ($d['near'] as $n) : ?>
					<li><a href="<?php echo esc_url(farhoon_pt_url($n['country'], $n['slug'])); ?>"><?php echo esc_html($n['name']); ?></a> <small><?php echo esc_html(farhoon_pt_n(number_format($n['km']), $cc) . ' كم'); ?></small></li>
				<?php endforeach; ?>
				<li><a href="<?php echo esc_url(farhoon_pt_url($d['country'])); ?>">كل مدن <?php echo esc_html($c['name']); ?></a></li>
			</ul>
		</section>

		<?php echo farhoon_cta('rafiq'); ?>
	</div>
	<?php
	// The next 40 days, so the page shows the right day even when served from the page cache.
	$js = [];
	if ($row) {
		foreach (array_slice($d['days'], $ti, 40) as $r) {
			$js[] = ['d' => $r[0], 'raw' => array_slice($r, 1, 6), 't' => array_map(fn($x) => farhoon_pt_time($x, $cc), array_slice($r, 1, 6)), 'label' => farhoon_pt_gdate($r[0], $d['country'], true, true) . ' · ' . farhoon_pt_hdate($r[7], $cc)];
		}
	}
	echo '<script type="application/json" id="pt-data">' . wp_json_encode(['tz' => $d['tz'], 'names' => array_values($names), 'cc' => $cc, 'days' => $js], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) . '</script>';
	farhoon_pt_schema($crumbs, ['@type' => 'City', 'name' => $d['name'], 'geo' => ['@type' => 'GeoCoordinates', 'latitude' => $d['lat'], 'longitude' => $d['lng']], 'containedInPlace' => ['@type' => 'Country', 'name' => $c['name']]]);

/* ======================= country ======================= */
elseif ($ctx['kind'] === 'country') :
	$slug = $ctx['country'];
	$c = $countries[$slug];
	$list = farhoon_pt_cities_of($slug);
	$first = farhoon_pt_city($slug, $list[0]['slug']);
	$method = farhoon_pt_method($first['method']);
	$cc = $c['cc'];
	?>
	<section class="f-band">
		<div class="f-wrap">
			<h1><?php echo esc_html($first['phrase'] . ' ' . $c['in'] . ' اليوم'); ?></h1>
			<?php $crumbs = farhoon_pt_crumbs([['مواقيت الصلاة', farhoon_pt_url()], [$c['name'], '']]); ?>
		</div>
	</section>
	<div class="f-wrap pt-body">
		<p class="pt-lead">أوقات الأذان اليوم في <?php echo esc_html(farhoon_pt_count(count($list), ['مدينة واحدة', 'مدينتين', 'مدن', 'مدينة'], $cc)); ?> <?php echo esc_html($c['in']); ?>، محسوبة بطريقة <strong><?php echo esc_html($method[0]); ?></strong>: <?php echo esc_html($method[1]); ?>. المرجع الرسمي هو تقويم <a href="<?php echo esc_url($c['url']); ?>" rel="noopener" target="_blank"><?php echo esc_html($c['auth']); ?></a>. اختر مدينتك لترى جدول الشهر واتجاه القبلة وإمساكية رمضان.</p>
		<div class="pt-scroll"><table class="pt-table">
			<thead><tr><th>المدينة</th><?php foreach ($names as $n) echo '<th>' . esc_html($n) . '</th>'; ?></tr></thead>
			<tbody>
			<?php foreach ($list as $it) :
				$cd = farhoon_pt_city($slug, $it['slug']);
				[, , $r] = farhoon_pt_today($cd); ?>
				<tr>
					<th scope="row"><a href="<?php echo esc_url(farhoon_pt_url($slug, $it['slug'])); ?>"><?php echo esc_html($it['name']); ?></a></th>
					<?php for ($k = 1; $k <= 6; $k++) echo '<td>' . ($r ? esc_html(farhoon_pt_time($r[$k], $cc)) : '—') . '</td>'; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<p class="pt-small">الأوقات لليوم <?php echo esc_html(farhoon_pt_gdate(farhoon_pt_today($first)[0], $slug)); ?> بالتوقيت المحلي.</p>
		<section class="pt-sec">
			<h2>إمساكية رمضان ١٤٤٨ <?php echo esc_html($c['in']); ?> (متوقعة)</h2>
			<p>يُتوقع أن يبدأ رمضان ١٤٤٨ يوم <?php echo esc_html(farhoon_pt_gdate($first['ramadan'][0][0], $slug, true, true)); ?> بحسب تقويم أم القرى، والبداية الفعلية <?php echo esc_html($c['in']); ?> تتبع إعلان رؤية الهلال. تجد إمساكية كل مدينة كاملة في صفحتها.</p>
			<div class="pt-scroll"><table class="pt-table">
				<thead><tr><th>المدينة</th><th>الإمساك في أول يوم</th><th>الإفطار في أول يوم</th><th>ساعات الصيام في أول يوم</th><th>ساعات الصيام في آخر يوم</th></tr></thead>
				<tbody>
				<?php foreach ($list as $it) :
					$cd = farhoon_pt_city($slug, $it['slug']);
					if (!$cd['ramadan']) continue;
					$f = $cd['ramadan'][0];
					$l = end($cd['ramadan']); ?>
					<tr>
						<th scope="row"><a href="<?php echo esc_url(farhoon_pt_url($slug, $it['slug']) . '#imsakiya'); ?>"><?php echo esc_html($it['name']); ?></a></th>
						<td><?php echo esc_html(farhoon_pt_time($f[2], $cc)); ?></td>
						<td><?php echo esc_html(farhoon_pt_time($f[7], $cc)); ?></td>
						<td><?php echo esc_html(farhoon_pt_duration(farhoon_pt_minutes($f[3], $f[7]), $cc)); ?></td>
						<td><?php echo esc_html(farhoon_pt_duration(farhoon_pt_minutes($l[3], $l[7]), $cc)); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		</section>
		<?php farhoon_pt_other_countries($slug); ?>
		<?php echo farhoon_cta('rafiq'); ?>
	</div>
	<?php farhoon_pt_schema($crumbs, ['@type' => 'Country', 'name' => $c['name']]);

/* ======================= Ramadan hub ======================= */
elseif ($ctx['kind'] === 'imsak') :
	$any = farhoon_pt_city('saudi-arabia', 'makkah');
	$r0 = $any['ramadan'][0];
	$rl = end($any['ramadan']);
	$eid = gmdate('Y-m-d', strtotime($rl[0] . ' 12:00 UTC') + DAY_IN_SECONDS);
	?>
	<section class="f-band">
		<div class="f-wrap">
			<h1>إمساكية رمضان ١٤٤٨ هـ (٢٠٢٧ م) للمدن العربية</h1>
			<p class="f-band-sub">مواعيد متوقعة، والبداية الفعلية تتبع رؤية الهلال</p>
			<?php $crumbs = farhoon_pt_crumbs([['إمساكية رمضان', '']]); ?>
		</div>
	</section>
	<div class="f-wrap pt-body">
		<section class="pt-sec">
			<h2>متى يبدأ رمضان ١٤٤٨؟</h2>
			<p>بحسب تقويم أم القرى يُتوقع أن يكون أول أيام رمضان ١٤٤٨ يوم <strong><?php echo esc_html(farhoon_pt_gdate($r0[0], 'saudi-arabia', true, true)); ?></strong> (متوقع)، وأن يكون الشهر <?php echo esc_html(farhoon_pt_count(count($any['ramadan']), ['يومًا', 'يومين', 'أيام', 'يومًا'], 'SA')); ?> في هذا التقويم، فيكون عيد الفطر يوم <?php echo esc_html(farhoon_pt_gdate($eid, 'saudi-arabia', true, true)); ?> (متوقع).</p>
			<p>هذه تواريخ حسابية متوقعة. تعلن كل دولة بداية الشهر ونهايته بحسب رؤية الهلال لديها، فقد تتقدم البداية أو تتأخر يومًا، وقد يكون الشهر ٢٩ يومًا أو ٣٠.</p>
		</section>
		<section class="pt-sec">
			<h2>الإمساك والإفطار في أول يوم وساعات الصيام</h2>
			<p>وقت الإمساك في جداولنا قبل الفجر بـ<?php echo esc_html(farhoon_pt_n($any['imsak_before_fajr'], 'SA')); ?> دقائق، وهو اصطلاح للاحتياط تعارف عليه الناس، أما الصيام شرعًا فيبدأ من طلوع الفجر. وساعات الصيام محسوبة من الفجر إلى المغرب.</p>
			<?php foreach ($countries as $slug => $c) :
				$list = farhoon_pt_cities_of($slug);
				if (!$list) continue; ?>
				<h3><?php echo esc_html($c['name']); ?></h3>
				<div class="pt-scroll"><table class="pt-table">
					<thead><tr><th>المدينة</th><th>الإمساك</th><th>الفجر</th><th>المغرب (الإفطار)</th><th>الصيام في أول يوم</th><th>الصيام في آخر يوم</th></tr></thead>
					<tbody>
					<?php foreach ($list as $it) :
						$cd = farhoon_pt_city($slug, $it['slug']);
						if (!$cd['ramadan']) continue;
						$f = $cd['ramadan'][0];
						$l = end($cd['ramadan']); ?>
						<tr>
							<th scope="row"><a href="<?php echo esc_url(farhoon_pt_url($slug, $it['slug']) . '#imsakiya'); ?>"><?php echo esc_html($it['name']); ?></a></th>
							<td><?php echo esc_html(farhoon_pt_time($f[2], $c['cc'])); ?></td>
							<td><?php echo esc_html(farhoon_pt_time($f[3], $c['cc'])); ?></td>
							<td><?php echo esc_html(farhoon_pt_time($f[7], $c['cc'])); ?></td>
							<td><?php echo esc_html(farhoon_pt_duration(farhoon_pt_minutes($f[3], $f[7]), $c['cc'])); ?></td>
							<td><?php echo esc_html(farhoon_pt_duration(farhoon_pt_minutes($l[3], $l[7]), $c['cc'])); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table></div>
			<?php endforeach; ?>
			<p class="pt-small">كل الأوقات بالتوقيت المحلي لكل مدينة، ومحسوبة بطريقة الحساب المعتمدة في بلدها كما في تطبيق رفيق الطاعة. تجد الإمساكية كاملة لأيام الشهر في صفحة كل مدينة.</p>
		</section>
		<?php echo farhoon_cta('rafiq'); ?>
	</div>
	<?php farhoon_pt_schema($crumbs);

/* ======================= prayer-times hub ======================= */
else :
	?>
	<section class="f-band">
		<div class="f-wrap">
			<h1>مواقيت الصلاة اليوم في المدن العربية</h1>
			<p class="f-band-sub">بطريقة الحساب المعتمدة في كل بلد، كما في تطبيق رفيق الطاعة</p>
			<?php $crumbs = farhoon_pt_crumbs([['مواقيت الصلاة', '']]); ?>
		</div>
	</section>
	<div class="f-wrap pt-body">
		<p class="pt-lead">اختر مدينتك لترى أوقات اليوم وجدول الشهر واتجاه القبلة والتاريخ الهجري. لكل بلد طريقة حساب تقارب تقويم جهته الرسمية، ونذكرها في صفحة كل مدينة مع رابط التقويم الرسمي. وللاستعداد للشهر الكريم: <a href="<?php echo esc_url(home_url('/ramadan-imsakiya/')); ?>">إمساكية رمضان ١٤٤٨ المتوقعة</a>.</p>
		<?php foreach ($countries as $slug => $c) :
			$list = farhoon_pt_cities_of($slug);
			if (!$list) continue;
			$m = farhoon_pt_method(farhoon_pt_city($slug, $list[0]['slug'])['method']); ?>
			<section class="pt-sec pt-country">
				<h2><a href="<?php echo esc_url(farhoon_pt_url($slug)); ?>"><?php echo esc_html($c['name']); ?></a> <small><?php echo esc_html('طريقة ' . $m[0]); ?></small></h2>
				<ul class="pt-grid">
					<?php foreach ($list as $it) :
						$cd = farhoon_pt_city($slug, $it['slug']);
						[, , $r] = farhoon_pt_today($cd); ?>
						<li><a href="<?php echo esc_url(farhoon_pt_url($slug, $it['slug'])); ?>"><strong><?php echo esc_html($it['name']); ?></strong>
							<?php if ($r) : ?><span>الفجر <?php echo esc_html(farhoon_pt_time($r[1], $c['cc'])); ?> · المغرب <?php echo esc_html(farhoon_pt_time($r[5], $c['cc'])); ?></span><?php endif; ?>
						</a></li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endforeach; ?>
		<?php echo farhoon_cta('rafiq'); ?>
	</div>
	<?php farhoon_pt_schema($crumbs);
endif;
?>
</main>
<?php get_footer();
