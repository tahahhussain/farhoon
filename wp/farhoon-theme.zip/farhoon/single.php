<?php
// One article, Arabic or English: title band, image, details, contents list, body with calls to action,
// FAQ, author, sharing, previous and next, related articles, comments and a closing call to action.
defined('ABSPATH') || exit;
get_header();
while (have_posts()) : the_post();
	$term = farhoon_primary_term();
	$faq = json_decode((string) get_post_meta(get_the_ID(), 'farhoon_faq', true), true) ?: [];
	$en = farhoon_lang() === 'en';
	?>
<main id="main" class="f-main">
	<section class="f-band f-band-article">
		<div class="f-wrap">
			<h1><?php the_title(); ?></h1>
			<?php farhoon_breadcrumbs(); ?>
		</div>
	</section>
	<article class="f-article">
		<?php if (has_post_thumbnail()) : ?>
			<figure class="f-hero"><?php the_post_thumbnail('farhoon-hero', ['loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 900px) 100vw, 860px']); ?></figure>
		<?php endif; ?>
		<div class="f-meta">
			<span class="f-meta-i f-meta-author"><?php echo esc_html(farhoon_t('فريق تحرير فرحون', 'Farhoon editorial team')); ?></span>
			<span class="f-meta-i f-meta-date"><time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(farhoon_date()); ?></time></span>
			<?php if (get_the_modified_time('U') - get_the_time('U') > DAY_IN_SECONDS) : ?>
				<span class="f-meta-i f-meta-upd"><?php echo esc_html(farhoon_t('حُدّثت', 'Updated')); ?> <time datetime="<?php echo esc_attr(get_the_modified_date('c')); ?>"><?php echo esc_html(farhoon_date(null, true)); ?></time></span>
			<?php endif; ?>
			<span class="f-meta-i f-meta-time"><?php echo esc_html(farhoon_minutes_label()); ?></span>
			<?php if ($term) : ?><a class="f-meta-i f-meta-cat" href="<?php echo esc_url(get_term_link($term)); ?>"><?php echo esc_html($term->name); ?></a><?php endif; ?>
		</div>
		<div class="f-content">
			<?php the_content(); ?>
		</div>
		<?php if ($faq) : ?>
			<section class="f-faq" id="faq">
				<h2><?php echo esc_html(farhoon_t('الأسئلة الشائعة', 'Frequently asked questions')); ?></h2>
				<?php foreach ($faq as $i => $f) : ?>
					<details<?php echo $i === 0 ? ' open' : ''; ?>><summary><?php echo esc_html($f['q']); ?></summary><p><?php echo esc_html($f['a']); ?></p></details>
				<?php endforeach; ?>
			</section>
		<?php endif; ?>
		<section class="f-author">
			<img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/img/face.png'); ?>" alt="" width="64" height="64" loading="lazy">
			<div>
				<strong><?php echo esc_html(farhoon_t('فريق تحرير فرحون', 'Farhoon editorial team')); ?></strong>
				<p><?php echo esc_html(farhoon_t('نكتب عن العبادات والزكاة وتربية الأطفال بلغة واضحة، ونرجع في الأحكام إلى القرآن والسنة وكتب أهل العلم. وللحالات الخاصة نوصي دائمًا بسؤال أهل العلم في بلدك.', 'We write about worship, zakat and raising children in plain language, checking rulings against the Quran, the Sunnah and the works of scholars. For personal cases, always ask a scholar where you live.')); ?></p>
			</div>
		</section>
		<?php farhoon_share(); ?>
		<nav class="f-prevnext" aria-label="<?php echo esc_attr(farhoon_t('مقالات أخرى', 'More articles')); ?>">
			<?php
			$prev = get_previous_post(true, '', $en ? 'en_category' : 'category') ?: get_previous_post();
			$next = get_next_post(true, '', $en ? 'en_category' : 'category') ?: get_next_post();
			if ($prev) echo '<a class="f-pn f-pn-prev" href="' . esc_url(get_permalink($prev)) . '"><small>' . esc_html(farhoon_t('السابق', 'Previous')) . '</small>' . esc_html(get_the_title($prev)) . '</a>';
			if ($next) echo '<a class="f-pn f-pn-next" href="' . esc_url(get_permalink($next)) . '"><small>' . esc_html(farhoon_t('التالي', 'Next')) . '</small>' . esc_html(get_the_title($next)) . '</a>';
			?>
		</nav>
	</article>
	<?php
	$related = new WP_Query([
		'post_type' => get_post_type(),
		'posts_per_page' => 3,
		'post__not_in' => [get_the_ID()],
		'ignore_sticky_posts' => true,
		'no_found_rows' => true,
		'tax_query' => $term ? [['taxonomy' => $term->taxonomy, 'terms' => [$term->term_id]]] : [],
	]);
	if ($related->post_count < 3) {
		$related = new WP_Query(['post_type' => get_post_type(), 'posts_per_page' => 3, 'post__not_in' => [get_the_ID()], 'ignore_sticky_posts' => true, 'no_found_rows' => true]);
	}
	if ($related->have_posts()) : ?>
		<section class="f-related f-wrap">
			<h2><?php echo esc_html(farhoon_t('مقالات ذات صلة', 'Related articles')); ?></h2>
			<div class="f-grid"><?php while ($related->have_posts()) : $related->the_post(); farhoon_card(); endwhile; wp_reset_postdata(); ?></div>
		</section>
	<?php endif; ?>
	<?php if (comments_open() || get_comments_number()) : ?>
		<section class="f-comments f-wrap"><?php comments_template(); ?></section>
	<?php endif; ?>
	<section class="f-endcta">
		<div class="f-wrap">
			<img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/img/face.png'); ?>" alt="" width="110" height="110" loading="lazy">
			<div>
				<h2><?php echo esc_html(farhoon_t('رفيقك اليومي في الطاعة', 'Your daily companion in worship')); ?></h2>
				<p><?php echo esc_html(farhoon_t('رفيق الطاعة يجمع المصحف والأذكار والمواقيت وحاسبة الزكاة وطاعاتك اليومية في تطبيق واحد مجاني بلا إعلانات. قريبًا على Google Play وApp Store.', 'Rafiq Al-Taa brings the Mushaf, adhkar, prayer times, a zakat calculator and your daily deeds into one free app with no ads. Coming soon to Google Play and the App Store.')); ?></p>
				<a class="f-btn f-btn-dark" href="<?php echo esc_url(farhoon_url('rafiq')); ?>"><?php echo esc_html(farhoon_t('اكتشف رفيق الطاعة', 'Discover Rafiq Al-Taa')); ?></a>
			</div>
		</div>
	</section>
</main>
<?php endwhile;
get_footer();
