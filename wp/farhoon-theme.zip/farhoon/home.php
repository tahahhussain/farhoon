<?php
// The posts page (/blog/) uses the same list as the archives.
defined('ABSPATH') || exit;
require __DIR__ . '/archive.php';
